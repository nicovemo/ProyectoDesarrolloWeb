/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.dev1.app.model.Administrativo;

import com.dev1.app.model.Usuario.Usuario;
import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "administrativos")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @ToString
public class Administrativo {

    @Id
    private Long id; // mismo id que Usuario

    @Column(nullable = false, length = 100)
    private String puesto;

    @Column(nullable = false, length = 100)
    private String departamento;

    @Column(nullable = false)
    private Boolean activo = true;

    @OneToOne
    @MapsId
    @JoinColumn(name = "id")
    private Usuario usuario;
}

    

