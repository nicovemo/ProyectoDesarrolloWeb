/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.dev1.app.model.Biblioteca;
import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "recursos")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @ToString
public class Biblioteca {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String titulo;
    private String tipo; // LIBRO, ARTÍCULO, ENLACE
    private String autor;
    private String enlace;
    private String descripcion;
}