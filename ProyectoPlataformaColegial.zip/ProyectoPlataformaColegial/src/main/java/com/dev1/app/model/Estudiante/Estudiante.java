/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.dev1.app.model.Estudiante;

import com.dev1.app.model.Usuario.Usuario;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.MapsId;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

/**
 *
 * @author Nicole Venegas
 */

@Entity
@Table(name="estudiantes")
public class Estudiante {
  @Id
  private Integer id; // mismo id que usuarios
  private String matricula;
  private String carrera;
  private Boolean transporteBeca;
  private Boolean comedorBeca;
  @OneToOne
  @MapsId
  @JoinColumn(name="id")
  private Usuario usuario;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getMatricula() {
        return matricula;
    }

    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }

    public String getCarrera() {
        return carrera;
    }

    public void setCarrera(String carrera) {
        this.carrera = carrera;
    }

    public Boolean getTransporteBeca() {
        return transporteBeca;
    }

    public void setTransporteBeca(Boolean transporteBeca) {
        this.transporteBeca = transporteBeca;
    }

    public Boolean getComedorBeca() {
        return comedorBeca;
    }

    public void setComedorBeca(Boolean comedorBeca) {
        this.comedorBeca = comedorBeca;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }
  
  
}


