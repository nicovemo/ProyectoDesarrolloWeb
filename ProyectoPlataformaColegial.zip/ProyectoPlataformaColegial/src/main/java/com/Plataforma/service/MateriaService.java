package com.Plataforma.service;

import com.ctp.profesores.entity.*;
import org.springframework.stereotype.Service;

@Service
public class MateriaService {

    private final MateriaRepository materiaRepo;
    private final ProfesorRepository profesorRepo;

    public MateriaService(MateriaRepository m, ProfesorRepository p) {
        this.materiaRepo = m;
        this.profesorRepo = p;
    }

    public java.util.List<Materia> listar(Long profesorId) {
        return materiaRepo.findByProfesorId(profesorId);
    }

    public Materia crear(String nombre, String codigo, Long profesorId, String especialidad, String descripcion) {
        Profesor prof = profesorRepo.findById(profesorId).orElseThrow();
        Materia m = new Materia();
        m.setNombre(nombre);
        m.setCodigo(codigo);
        m.setProfesor(prof);
        return materiaRepo.save(m);
    }

    public Object listar() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public void eliminar(Long id) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
