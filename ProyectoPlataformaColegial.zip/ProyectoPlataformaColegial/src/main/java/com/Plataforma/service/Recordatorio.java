/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.Plataforma.service;

import com.ctp.profesores.entity.Evento;
import com.ctp.profesores.entity.Profesor;
import com.dev1.app.model.Usuario.Usuario;
import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "recordatorios")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @ToString
public class Recordatorio {

    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(optional = false)
    private Evento evento;

    @ManyToOne(optional = false)
    private Usuario usuario;

    @Column(nullable = false)
    private Integer anticipacionMinutos = 60; // 1 hora por defecto

    @Column(nullable = false, length = 20)
    private String medio = "INAPP"; // luego puedes añadir EMAIL/SMS

    @Column(nullable = false)
    private java.time.LocalDateTime creadoEn = java.time.LocalDateTime.now();

    void setEvento(Evento evento) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    void setUsuario(Usuario usuario) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    void setAnticipacionMinutos(Integer anticipacionMinutos) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    void setMedio(String medio) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    void setProfesor(Profesor prof) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    void setAsunto(String asunto) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    void setCuerpo(String cuerpo) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    void setDestino(String join) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
