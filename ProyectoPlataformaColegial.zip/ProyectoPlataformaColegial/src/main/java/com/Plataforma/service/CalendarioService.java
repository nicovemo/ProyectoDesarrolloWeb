package com.Plataforma.service;

import com.ctp.profesores.entity.Evento;
import com.Plataforma.repository.EventoRepository;
import org.springframework.stereotype.Service;

@Service
public class CalendarioService {

    private final EventoRepository repo;

    public CalendarioService(EventoRepository r) {
        this.repo = r;
    }

    public java.util.List<Evento> listar(Long profesorId) {
        return repo.findByProfesorIdOrProfesorIsNullOrderByFechaInicioAsc(profesorId);
    }
}
