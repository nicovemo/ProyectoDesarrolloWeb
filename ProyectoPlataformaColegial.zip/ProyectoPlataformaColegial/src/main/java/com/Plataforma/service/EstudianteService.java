/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.Plataforma.service;

import com.Plataforma.repository.EstudianteRepository;
import com.dev1.app.model.Estudiante.Estudiante;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author Nicole Venegas
 */
@Service
public class EstudianteService {
  @Autowired EstudianteRepository estudianteRepo;
  public Estudiante getById(Integer id){
    return estudianteRepo.findByUsuario_Id(id).orElse(null);
  }
}

