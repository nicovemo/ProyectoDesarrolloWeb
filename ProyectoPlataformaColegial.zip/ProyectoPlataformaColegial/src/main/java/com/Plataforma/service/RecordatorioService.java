package com.Plataforma.service;

import com.Plataforma.repository.RecordatorioRepository;
import com.ctp.profesores.entity.*;
import com.dev1.app.model.Usuario.Usuario;
import com.dev1.app.model.Usuario.UsuarioRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class RecordatorioService {

    private final RecordatorioRepository repo;
    private final ProfesorRepository profesorRepo;
    private final EventoRepository eventoRepo;
    private final UsuarioRepository usuarioRepo;

    public RecordatorioService(JavaMailSender m, RecordatorioRepository r, ProfesorRepository p, com.ctp.profesores.entity.EventoRepository eventoRepo, com.dev1.app.model.Usuario.UsuarioRepository usuarioRepo) {
        this.repo = r;
        this.profesorRepo = p;
        this.eventoRepo = eventoRepo;
        this.usuarioRepo = usuarioRepo;
    }

    public void enviar(Long profesorId, String asunto, String cuerpo, java.util.List<String> correos) {
        SimpleMailMessage msg = new SimpleMailMessage();
        msg.setSubject(asunto);
        msg.setText(cuerpo);
        msg.setTo(correos.toArray(String[]::new));
        Profesor prof = profesorRepo.findById(profesorId).orElseThrow();
        Recordatorio rec = new Recordatorio();
        rec.setProfesor(prof);
        rec.setAsunto(asunto);
        rec.setCuerpo(cuerpo);
        rec.setDestino(String.join(",", correos));
        repo.save(rec);
    }
    
    @Transactional
    public com.Plataforma.service.Recordatorio crear(Long eventoId, Long usuarioId, Integer anticipacionMinutos, String medio) {

        Evento evento = eventoRepo.findById(eventoId)
                .orElseThrow(() -> new IllegalArgumentException("Evento no encontrado: " + eventoId));

        Usuario usuario = usuarioRepo.findById(usuarioId)
                .orElseThrow(() -> new IllegalArgumentException("Usuario no encontrado: " + usuarioId));

        com.Plataforma.service.Recordatorio r = new com.Plataforma.service.Recordatorio();
        r.setEvento(evento);
        r.setUsuario(usuario);

        if (anticipacionMinutos != null && anticipacionMinutos > 0)
            r.setAnticipacionMinutos(anticipacionMinutos);

        if (medio != null && !medio.isBlank())
            r.setMedio(medio);

        return recordatorioRepo.save(r);
    }
}

