/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.Plataforma.service;

import com.dev1.app.model.Biblioteca.Biblioteca;
import com.dev1.app.model.Biblioteca.BibliotecaRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;


@Service
public class BibliotecaService {

    private final BibliotecaRepository repo;

    public BibliotecaService(BibliotecaRepository repo) {
        this.repo = repo;
    }

    public List<Biblioteca> listar() {
        return repo.findAll();
    }

    public List<Biblioteca> buscar(String query) {
        return (query == null || query.isBlank()) ? listar()
                : repo.findByTituloContainingIgnoreCase(query);
    }
}