package com.Plataforma.service;

import com.Plataforma.repository.RecursoRepository;
import com.ctp.profesores.entity.*;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import java.nio.file.*;
import java.io.IOException;
import java.util.UUID;

@Service
public class RecursoService {

    private final RecursoRepository recursoRepo;
    private final MateriaRepository materiaRepo;
    private final ProfesorRepository profesorRepo;

    public RecursoService(RecursoRepository r, MateriaRepository m, ProfesorRepository p) {
        this.recursoRepo = r;
        this.materiaRepo = m;
        this.profesorRepo = p;
    }

    public Recurso guardar(Long materiaId, Long profesorId, MultipartFile file, String titulo, String descripcion) throws IOException {
        Profesor p = profesorRepo.findById(profesorId).orElseThrow();
        Materia m = materiaRepo.findById(materiaId).orElseThrow();
        String stored = UUID.randomUUID() + "_" + Path.of(file.getOriginalFilename()).getFileName().toString();
        Path target = Path.of("uploads").resolve(stored);
        Files.createDirectories(target.getParent());
        Files.copy(file.getInputStream(), target, StandardCopyOption.REPLACE_EXISTING);
        Recurso r = new Recurso();
        r.setProfesor(p);
        r.setMateria(m);
        r.setTitulo(titulo);
        r.setDescripcion(descripcion);
        r.setFilename(stored);
        r.setOriginalName(file.getOriginalFilename());
        r.setContentType(file.getContentType());
        r.setSize(file.getSize());
        return recursoRepo.save(r);
    }
}
