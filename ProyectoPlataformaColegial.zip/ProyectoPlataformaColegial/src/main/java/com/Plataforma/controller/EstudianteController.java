/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.Plataforma.controller;


import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.Arrays;

@Controller
public class EstudianteController {

    @GetMapping("/estudiante/home")
    public String home(Model model) {
        // Placeholders para compilar; reemplaza con tus servicios reales
        model.addAttribute("estudiante", "Demo Estudiante");
        model.addAttribute("calendario", Arrays.asList("Evento 1", "Evento 2"));
        model.addAttribute("biblioteca", Arrays.asList("Recurso A", "Recurso B"));
        return "estudiante/home";
    }

    @GetMapping("/estudiante/perfil")
    public String perfil(Model model) {
        model.addAttribute("estudiante", "Demo Estudiante");
        return "estudiante/perfil";
    }
}

