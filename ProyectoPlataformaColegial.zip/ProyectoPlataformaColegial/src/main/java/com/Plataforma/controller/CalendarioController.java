/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.Plataforma.controller;

import com.Plataforma.service.RecordatorioService;
import com.ctp.profesores.entity.EventoRepository;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequiredArgsConstructor
public class CalendarioController {

    private final EventoRepository eventoRepository;
    private final RecordatorioService recordatorioService;

    @GetMapping("/calendario")
    public String mostrarCalendario(Model model) {
        model.addAttribute("eventos", eventoRepository.findAll());
        return "general/calendario";
    }

    @PostMapping("/calendario/recordatorios")
    public String crearRecordatorio(
            @RequestParam Long eventoId,
            @RequestParam Long usuarioId,
            @RequestParam(required = false) Integer anticipacionMinutos,
            @RequestParam(required = false, defaultValue = "INAPP") String medio
    ) {
        recordatorioService.crear(eventoId, usuarioId, anticipacionMinutos, medio);
        return "redirect:/calendario";
    }
}