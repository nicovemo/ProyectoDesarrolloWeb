package com.Plataforma.controller;

import com.Plataforma.service.MateriaService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequiredArgsConstructor
@RequestMapping("/profesor/materias")
public class MateriaController {

    private final MateriaService service;

    @GetMapping
    public String listar(Model model) {
        model.addAttribute("materias", service.listar(1L));
        return "profesor/materias/list";
    }

    @PostMapping("/crear")
    public String crearMateria(
            @RequestParam String nombre,
            @RequestParam String codigo,
            @RequestParam Long profesorId,
            @RequestParam(required = false) String especialidad,
            @RequestParam(required = false) String descripcion
    ) {
        service.crear(nombre, codigo, profesorId, especialidad, descripcion);
        return "redirect:/admin/materias";
    }
}