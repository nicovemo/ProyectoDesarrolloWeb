/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.Plataforma.controller;

import com.dev1.app.model.Administrativo.Administrativo;
import com.Plataforma.service.AdministrativoService;
import com.Plataforma.service.MateriaService;
import com.dev1.app.model.Estudiante.EstudianteRepository;
import com.dev1.app.model.Usuario.UsuarioRepository;
import com.ctp.profesores.entity.Materia;
import com.ctp.profesores.entity.ProfesorRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;


@Controller
@RequiredArgsConstructor
@RequestMapping("/admin")
public class AdminController {

    private final AdministrativoService administrativoService;
    private final UsuarioRepository usuarioRepository;
    private final EstudianteRepository estudianteRepository;
    private final ProfesorRepository profesorRepository;
    private final MateriaService materiaService;

    // === Dashboard ===
    @GetMapping({"", "/", "/dashboard"})
    public String dashboard(Model model) {
        model.addAttribute("totalUsuarios", usuarioRepository.count());
        model.addAttribute("totalEstudiantes", estudianteRepository.count());
        model.addAttribute("totalProfesores", profesorRepository.count());
        model.addAttribute("totalAdministrativos", administrativoService.listar().size());
        model.addAttribute("totalMaterias", materiaService.listar());
        return "admin/dashboard";
    }

    // === Usuarios ===
    @GetMapping("/usuarios")
    public String usuarios(Model model) {
        model.addAttribute("estudiantes", estudianteRepository.findAll());
        model.addAttribute("profesores", profesorRepository.findAll());
        model.addAttribute("administrativos", administrativoService.listar());
        return "admin/usuarios";
    }

    @PostMapping("/usuarios/administrativo")
    public String crearAdministrativo(
            @RequestParam Long usuarioId,
            @RequestParam String puesto,
            @RequestParam String departamento
    ) {
        administrativoService.crearDesdeUsuario(usuarioId, puesto, departamento);
        return "redirect:/admin/usuarios";
    }

    // === Materias (CRUD) ===
    @GetMapping("/materias")
    public String materias(Model model) {
        model.addAttribute("materias", materiaService.listar());
        model.addAttribute("profesores", profesorRepository.findAll());
        model.addAttribute("materiaForm", new Materia());
        return "admin/materias";
    }

    @PostMapping("/materias")
    public String crearMateria(
            @RequestParam String nombre,
            @RequestParam String codigo,
            @RequestParam Long profesorId,
            @RequestParam(required = false) String especialidad,
            @RequestParam(required = false) String descripcion
    ) {
        materiaService.crear(nombre, codigo, profesorId, especialidad, descripcion);
        return "redirect:/admin/materias";
    }

    @PostMapping("/materias/{id}/eliminar")
    public String eliminarMateria(@PathVariable Long id) {
        materiaService.eliminar(id);
        return "redirect:/admin/materias";
    }
}