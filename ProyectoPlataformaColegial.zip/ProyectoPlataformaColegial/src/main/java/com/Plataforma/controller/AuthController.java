/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.Plataforma.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class AuthController {

    @GetMapping("/login")
    public String loginForm(Model model) {
        model.addAttribute("mensaje", "Ingrese sus credenciales");
        return "auth/login";
    }

    @PostMapping("/login")
    public String doLogin(@RequestParam String correo,
                          @RequestParam String password,
                          Model model) {
        // TODO: autenticar contra tu servicio/BD
        if (correo != null && !correo.isBlank()) {
            model.addAttribute("usuario", correo);
            return "redirect:/profesor/dashboard";
        }
        model.addAttribute("error", "Credenciales inválidas");
        return "auth/login";
    }
}


