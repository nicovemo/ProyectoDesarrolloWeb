package com.Plataforma.repository;
import org.springframework.data.jpa.repository.JpaRepository; import com.ctp.profesores.entity.Comunicado;
public interface ComunicadoRepository extends JpaRepository<Comunicado, Long>{ java.util.List<Comunicado> findByMateriaIdOrderByFechaPublicacionDesc(Long materiaId);}