package com.Plataforma.repository;
import org.springframework.data.jpa.repository.JpaRepository; import com.ctp.profesores.entity.Evento;
public interface EventoRepository extends JpaRepository<Evento, Long>{ java.util.List<Evento> findByProfesorIdOrProfesorIsNullOrderByFechaInicioAsc(Long profesorId);}