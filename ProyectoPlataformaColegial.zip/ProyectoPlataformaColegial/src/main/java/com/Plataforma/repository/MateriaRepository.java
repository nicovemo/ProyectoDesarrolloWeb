package com.Plataforma.repository;
import org.springframework.data.jpa.repository.JpaRepository; import com.ctp.profesores.entity.Materia;
public interface MateriaRepository extends JpaRepository<Materia, Long>{ java.util.Optional<Materia> findByCodigo(String codigo); java.util.List<Materia> findByProfesorId(Long profesorId);}