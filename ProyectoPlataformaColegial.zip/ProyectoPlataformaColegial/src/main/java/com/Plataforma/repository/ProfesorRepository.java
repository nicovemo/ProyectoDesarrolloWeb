package com.Plataforma.repository;
import org.springframework.data.jpa.repository.JpaRepository; import com.ctp.profesores.entity.Profesor; import java.util.Optional;
public interface ProfesorRepository extends JpaRepository<Profesor, Long>{ Optional<Profesor> findByCorreo(String correo); }