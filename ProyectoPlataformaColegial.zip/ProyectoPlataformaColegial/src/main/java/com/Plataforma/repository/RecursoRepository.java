package com.Plataforma.repository;
import org.springframework.data.jpa.repository.JpaRepository; import com.ctp.profesores.entity.Recurso;
public interface RecursoRepository extends JpaRepository<Recurso, Long>{ java.util.List<Recurso> findByMateriaId(Long materiaId);}