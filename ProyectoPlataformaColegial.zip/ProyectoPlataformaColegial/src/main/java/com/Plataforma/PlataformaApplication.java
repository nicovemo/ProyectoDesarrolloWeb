/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.Plataforma;

/**
 *
 * @author Nicole Venegas
 */
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.stereotype.Controller;

@SpringBootApplication
public class PlataformaApplication {

	public static void main(String[] args) {
		SpringApplication.run(PlataformaApplication.class, args);
	}
        
@Controller
class RootController {
  @GetMapping("/")
  public String root() { return "redirect:/profesor/dashboard"; }

}
}
