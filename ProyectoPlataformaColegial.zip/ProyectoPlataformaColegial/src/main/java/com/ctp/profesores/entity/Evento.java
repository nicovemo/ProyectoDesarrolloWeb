package com.ctp.profesores.entity;
import jakarta.persistence.*; import jakarta.validation.constraints.*; import java.time.LocalDateTime;
@Entity public class Evento{
  @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
  @ManyToOne private Profesor profesor;
  @NotBlank @Column(length=150) private String titulo;
  @Lob private String descripcion;
  @NotNull private LocalDateTime fechaInicio;
  @NotNull private LocalDateTime fechaFin;
  private String tipo = "INSTITUCIONAL";
  public Long getId(){return id;} public void setId(Long id){this.id=id;}
  public Profesor getProfesor(){return profesor;} public void setProfesor(Profesor p){this.profesor=p;}
  public String getTitulo(){return titulo;} public void setTitulo(String t){this.titulo=t;}
  public String getDescripcion(){return descripcion;} public void setDescripcion(String d){this.descripcion=d;}
  public LocalDateTime getFechaInicio(){return fechaInicio;} public void setFechaInicio(LocalDateTime f){this.fechaInicio=f;}
  public LocalDateTime getFechaFin(){return fechaFin;} public void setFechaFin(LocalDateTime f){this.fechaFin=f;}
  public String getTipo(){return tipo;} public void setTipo(String t){this.tipo=t;}
}