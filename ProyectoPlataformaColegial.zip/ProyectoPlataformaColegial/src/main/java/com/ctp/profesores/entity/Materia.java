package com.ctp.profesores.entity;
import jakarta.persistence.*; import jakarta.validation.constraints.*;
@Entity public class Materia{
  @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
  @NotBlank @Column(length=120) private String nombre;
  @NotBlank @Column(length=30,unique=true) private String codigo;
  @ManyToOne(optional=false) private Profesor profesor;
  public Long getId(){return id;} public void setId(Long id){this.id=id;}
  public String getNombre(){return nombre;} public void setNombre(String n){this.nombre=n;}
  public String getCodigo(){return codigo;} public void setCodigo(String c){this.codigo=c;}
  public Profesor getProfesor(){return profesor;} public void setProfesor(Profesor p){this.profesor=p;}

    void setEspecialidad(String especialidad) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    void setDescripcion(String descripcion) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}