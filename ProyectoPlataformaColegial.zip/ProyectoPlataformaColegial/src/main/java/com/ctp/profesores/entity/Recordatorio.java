package com.ctp.profesores.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import java.time.LocalDateTime;

@Entity
public class Recordatorio {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @ManyToOne(optional = false)
    private Profesor profesor;
    @NotBlank
    @Column(length = 150)
    private String asunto;
    @NotBlank
    @Lob
    private String cuerpo;
    @NotBlank
    @Lob
    private String destino;
    private LocalDateTime fechaEnvio = LocalDateTime.now();

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Profesor getProfesor() {
        return profesor;
    }

    public void setProfesor(Profesor p) {
        this.profesor = p;
    }

    public String getAsunto() {
        return asunto;
    }

    public void setAsunto(String a) {
        this.asunto = a;
    }

    public String getCuerpo() {
        return cuerpo;
    }

    public void setCuerpo(String c) {
        this.cuerpo = c;
    }

    public String getDestino() {
        return destino;
    }

    public void setDestino(String d) {
        this.destino = d;
    }

    public LocalDateTime getFechaEnvio() {
        return fechaEnvio;
    }

    public void setFechaEnvio(LocalDateTime f) {
        this.fechaEnvio = f;
    }
}
