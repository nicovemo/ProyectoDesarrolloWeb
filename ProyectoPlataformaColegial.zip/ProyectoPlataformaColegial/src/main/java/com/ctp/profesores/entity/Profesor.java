package com.ctp.profesores.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;

@Entity
public class Profesor {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @NotBlank
    @Column(length = 120)
    private String nombre;
    @NotBlank
    @Email
    @Column(unique = true, length = 120)
    private String correo;
    @NotBlank
    private String passwordHash;
    private boolean activo = true;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String n) {
        this.nombre = n;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String c) {
        this.correo = c;
    }

    public String getPasswordHash() {
        return passwordHash;
    }

    public void setPasswordHash(String p) {
        this.passwordHash = p;
    }

    public boolean isActivo() {
        return activo;
    }

    public void setActivo(boolean a) {
        this.activo = a;
    }
}
