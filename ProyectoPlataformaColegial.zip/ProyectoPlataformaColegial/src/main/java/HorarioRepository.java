
import org.springframework.data.jpa.repository.JpaRepository; import com.ctp.profesores.entity.Horario;
public interface HorarioRepository extends JpaRepository<Horario, Long>{ java.util.List<Horario> findByMateriaId(Long materiaId);}