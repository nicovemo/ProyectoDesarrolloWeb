// ARCHIVO MOVIDO A com.Plataforma.repository.HorarioRepository
// Este archivo debe estar en la estructura correcta de paquetes