/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.Plataforma.controller;

import com.Plataforma.repository.EventoRepository;
import com.ctp.profesores.entity.Evento;
import java.time.LocalDateTime;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author Nicole Venegas
 */
@RestController
@RequestMapping("/api/estudiantes")
public class EstudianteApiController {
  @Autowired EventoRepository eventoRepo;
  @GetMapping("/{id}/recordatorios")
  public List<Evento> recordatorios(@PathVariable Long id){
    // devolver próximos 5 eventos - usando el método existente del EventoRepository
    return eventoRepo.findByProfesorIdOrProfesorIsNullOrderByFechaInicioAsc(id);
  }
}
