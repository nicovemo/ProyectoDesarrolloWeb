package com.Plataforma.controller;

import com.dev1.app.model.Usuario.Usuario;
import com.dev1.app.model.Estudiante.Estudiante;
import com.Plataforma.service.UsuarioService;
import com.Plataforma.service.EstudianteService;
import com.Plataforma.service.EventoCalendarioService;
import com.Plataforma.service.ComunicadoService;
import com.Plataforma.service.MateriaService;
import com.Plataforma.domain.EventoCalendario;
import com.Plataforma.domain.Comunicado;
import com.ctp.profesores.entity.Materia;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

@Controller
@RequestMapping("/estudiante")
public class EstudianteController {

    @Autowired
    private UsuarioService usuarioService;
    
    @Autowired
    private EstudianteService estudianteService;
    
    @Autowired
    private EventoCalendarioService eventoCalendarioService;
    
    @Autowired
    private ComunicadoService comunicadoService;
    
    @Autowired
    private MateriaService materiaService;

    /**
     * Obtiene el estudiante actual autenticado
     */
    private Estudiante obtenerEstudianteActual() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        String email = auth.getName();
        Usuario usuario = usuarioService.buscarPorEmail(email);
        return estudianteService.getById(usuario.getId());
    }

    @GetMapping("/biblioteca")
    public String biblioteca(Model model) {
        Estudiante estudiante = obtenerEstudianteActual();
        if (estudiante != null) {
            model.addAttribute("estudiante", estudiante);
        }
        
        // Aquí podrías obtener recursos de biblioteca específicos del estudiante
        model.addAttribute("recursos", List.of()); // Placeholder
        
        return "biblioteca"; // Usa la página de biblioteca existente
    }

    @GetMapping("/becas")
    public String becas(Model model) {
        Estudiante estudiante = obtenerEstudianteActual();
        if (estudiante != null) {
            model.addAttribute("estudiante", estudiante);
        }
        
        return "becas"; // Usa la página de becas existente
    }

    @GetMapping("/materias")
    public String materias(Model model) {
        Estudiante estudiante = obtenerEstudianteActual();
        if (estudiante != null) {
            model.addAttribute("estudiante", estudiante);
        }
        
        // Obtener todas las materias disponibles
        List<Materia> materias = materiaService.listar();
        model.addAttribute("materias", materias);
        
        return "estudiante/materias";
    }

    @GetMapping("/horarios")
    public String horarios(Model model) {
        Estudiante estudiante = obtenerEstudianteActual();
        if (estudiante != null) {
            model.addAttribute("estudiante", estudiante);
        }
        
        // Obtener eventos del calendario académico
        List<EventoCalendario> eventos = eventoCalendarioService.listarTodos();
        model.addAttribute("eventos", eventos);
        
        return "estudiante/horarios";
    }

    @GetMapping("/comunicados")
    public String comunicados(Model model) {
        Estudiante estudiante = obtenerEstudianteActual();
        if (estudiante != null) {
            model.addAttribute("estudiante", estudiante);
        }
        
        // Obtener comunicados publicados
        List<Comunicado> comunicados = comunicadoService.listarPublicados();
        model.addAttribute("comunicados", comunicados);
        
        return "estudiante/comunicados";
    }

    @GetMapping("/perfil")
    public String perfil(Model model) {
        Estudiante estudiante = obtenerEstudianteActual();
        if (estudiante != null) {
            model.addAttribute("estudiante", estudiante);
            model.addAttribute("estadisticas", estudianteService.obtenerEstadisticasAcademicas(estudiante.getId()));
        }
        
        return "estudiante/perfil";
    }
}

