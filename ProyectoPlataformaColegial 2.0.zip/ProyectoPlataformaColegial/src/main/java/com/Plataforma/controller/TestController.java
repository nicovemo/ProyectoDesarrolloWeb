package com.Plataforma.controller;

import com.dev1.app.model.Usuario.Usuario;
import com.dev1.app.model.Usuario.Rol;
import com.Plataforma.service.UsuarioService;
import com.ctp.profesores.entity.Profesor;
import com.Plataforma.repository.ProfesorRepository;
import com.ctp.profesores.entity.Materia;
import com.Plataforma.service.MateriaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/test")
public class TestController {

    @Autowired
    private UsuarioService usuarioService;
    
    @Autowired
    private PasswordEncoder passwordEncoder;
    
    @Autowired
    private ProfesorRepository profesorRepository;
    
    @Autowired
    private MateriaService materiaService;

    @GetMapping("/create-users")
    public String createTestUsers() {
        try {
            // Crear usuario administrador
            if (!usuarioService.existeEmail("admin@plataforma.edu")) {
                Usuario admin = new Usuario();
                admin.setUsername("admin");
                admin.setEmail("admin@plataforma.edu");
                admin.setPassword("secret");
                admin.setNombre("Administrador");
                admin.setApellido("Sistema");
                admin.setRol(Rol.ADMINISTRATIVO);
                usuarioService.guardar(admin);
            }

            // Crear usuario profesor
            if (!usuarioService.existeEmail("profesor@plataforma.edu")) {
                Usuario profesor = new Usuario();
                profesor.setUsername("profesor");
                profesor.setEmail("profesor@plataforma.edu");
                profesor.setPassword("secret");
                profesor.setNombre("Juan Carlos");
                profesor.setApellido("Pérez");
                profesor.setRol(Rol.PROFESOR);
                usuarioService.guardar(profesor);
            }

            // Crear usuario estudiante
            if (!usuarioService.existeEmail("estudiante@plataforma.edu")) {
                Usuario estudiante = new Usuario();
                estudiante.setUsername("estudiante");
                estudiante.setEmail("estudiante@plataforma.edu");
                estudiante.setPassword("secret");
                estudiante.setNombre("María José");
                estudiante.setApellido("González");
                estudiante.setRol(Rol.ESTUDIANTE);
                usuarioService.guardar(estudiante);
            }

            return """
                ✅ Usuarios de prueba disponibles:
                
                👨‍💼 ADMINISTRADOR:
                Email: admin@plataforma.edu
                Password: secret
                
                👨‍🏫 PROFESOR:
                Email: profesor@plataforma.edu
                Password: secret
                
                👨‍🎓 ESTUDIANTE:
                Email: estudiante@plataforma.edu
                Password: secret
                
                🔐 Prueba login en: http://localhost:8082/login
                """;

        } catch (Exception e) {
            return "Error al crear usuarios: " + e.getMessage() + 
                   "\n\nPuede que ya existan o haya un problema con la base de datos.";
        }
    }

    @GetMapping("/verify-password")
    public String verifyPassword() {
        try {
            Usuario admin = usuarioService.buscarPorEmail("admin@plataforma.edu");
            if (admin != null) {
                return """
                    🔍 Usuario encontrado:
                    - Email: %s
                    - Username: %s
                    - Rol: %s
                    - Password hash: %s...
                    
                    ✅ Usa la contraseña: secret
                    """.formatted(
                    admin.getEmail(),
                    admin.getUsername(), 
                    admin.getRol(),
                    admin.getPassword().substring(0, 20)
                );
            } else {
                return "❌ No se encontró usuario admin. Ejecuta /api/test/create-users primero.";
            }
        } catch (Exception e) {
            return "Error: " + e.getMessage();
        }
    }

    @GetMapping("/generate-hash")
    public String generateHash() {
        String password = "secret";
        String hash = passwordEncoder.encode(password);
        return """
            🔑 GENERADOR DE HASH:
            
            Password: %s
            Hash BCrypt: %s
            
            📋 Script SQL actualizado:
            
            DELETE FROM usuarios WHERE username IN ('admin', 'profesor', 'estudiante');
            
            INSERT INTO usuarios (username, email, password_hash, nombre, apellido, rol, activo, fecha_creacion) 
            VALUES ('admin', 'admin@plataforma.edu', '%s', 'Administrador', 'Sistema', 'ADMINISTRATIVO', true, NOW());
            
            INSERT INTO usuarios (username, email, password_hash, nombre, apellido, rol, activo, fecha_creacion) 
            VALUES ('profesor', 'profesor@plataforma.edu', '%s', 'Juan Carlos', 'Pérez', 'PROFESOR', true, NOW());
            
            INSERT INTO usuarios (username, email, password_hash, nombre, apellido, rol, activo, fecha_creacion) 
            VALUES ('estudiante', 'estudiante@plataforma.edu', '%s', 'María José', 'González', 'ESTUDIANTE', true, NOW());
            
            ✅ Ejecuta este script para actualizar los usuarios con el hash correcto.
            """.formatted(password, hash, hash, hash, hash);
    }

    @GetMapping("/debug-login")
    public String debugLogin() {
        try {
            Usuario admin = usuarioService.buscarPorEmail("admin@plataforma.edu");
            if (admin == null) {
                return "❌ Usuario no encontrado";
            }
            
            // Verificar si la contraseña está correctamente hasheada
            String testPassword = "secret";
            String storedHash = admin.getPassword();
            boolean matches = passwordEncoder.matches(testPassword, storedHash);
            
            // Generar un nuevo hash para comparar
            String newHash = passwordEncoder.encode(testPassword);
            boolean newHashMatches = passwordEncoder.matches(testPassword, newHash);
            
            return """
                🔧 DEBUG LOGIN DETALLADO:
                
                📧 Email: %s
                👤 Username: %s
                🔐 Password Hash completo: %s
                🎭 Rol: %s
                ✅ Activo: %s
                
                🧪 Test password 'secret' vs stored hash: %s
                🆕 Nuevo hash generado: %s
                🧪 Test password 'secret' vs nuevo hash: %s
                
                📏 Longitud hash almacenado: %d
                📏 Longitud hash esperado: %d
                
                🔍 Hash almacenado empieza con $2a$10$: %s
                🔍 Primer carácter: '%s' (ASCII: %d)
                🔍 Último carácter: '%s' (ASCII: %d)
                
                ❓ Problema detectado: %s
                """.formatted(
                admin.getEmail(),
                admin.getUsername(),
                storedHash,
                admin.getRol(),
                admin.getActivo(),
                matches ? "✅ CORRECTO" : "❌ INCORRECTO",
                newHash,
                newHashMatches ? "✅ CORRECTO" : "❌ INCORRECTO",
                storedHash.length(),
                "$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi".length(),
                storedHash.startsWith("$2a$10$") ? "✅ SÍ" : "❌ NO",
                storedHash.charAt(0),
                (int)storedHash.charAt(0),
                storedHash.charAt(storedHash.length()-1),
                (int)storedHash.charAt(storedHash.length()-1),
                !matches && !newHashMatches ? "PasswordEncoder no funciona correctamente" :
                !matches && newHashMatches ? "Hash almacenado corrupto o incorrecto" :
                "Sin problemas detectados"
            );
            
        } catch (Exception e) {
            return "Error en debug: " + e.getMessage();
        }
    }
    
    @GetMapping("/create-complete-data")
    public String createCompleteTestData() {
        try {
            StringBuilder resultado = new StringBuilder("🚀 CREANDO DATOS COMPLETOS DE PRUEBA:\n\n");
            
            // 1. Crear usuarios si no existen
            Usuario usuarioProfesor = null;
            if (!usuarioService.existeEmail("profesor@plataforma.edu")) {
                Usuario profesor = new Usuario();
                profesor.setUsername("profesor");
                profesor.setEmail("profesor@plataforma.edu");
                profesor.setPassword("secret");
                profesor.setNombre("Juan Carlos");
                profesor.setApellido("Pérez");
                profesor.setRol(Rol.PROFESOR);
                usuarioProfesor = usuarioService.guardar(profesor);
                resultado.append("✅ Usuario profesor creado\n");
            } else {
                usuarioProfesor = usuarioService.buscarPorEmail("profesor@plataforma.edu");
                resultado.append("ℹ️ Usuario profesor ya existía\n");
            }
            
            // 2. Crear entidad Profesor si no existe
            final Usuario usuarioProfesorFinal = usuarioProfesor;
            Profesor profesor = profesorRepository.findAll().stream()
                .filter(p -> p.getUsuario() != null && p.getUsuario().getId().equals(usuarioProfesorFinal.getId()))
                .findFirst()
                .orElse(null);
                
            if (profesor == null) {
                profesor = new Profesor();
                profesor.setUsuario(usuarioProfesorFinal);
                profesor.setCedula("12345678");
                profesor.setTelefono("88888888");
                profesor.setEspecialidad("Informática");
                profesor.setNombre("Juan Carlos Pérez");
                profesor.setCorreo("profesor@plataforma.edu");
                profesor.setPasswordHash(passwordEncoder.encode("secret"));
                profesor.setActivo(true);
                profesor = profesorRepository.save(profesor);
                resultado.append("✅ Entidad Profesor creada (ID: " + profesor.getId() + ")\n");
            } else {
                resultado.append("ℹ️ Entidad Profesor ya existía (ID: " + profesor.getId() + ")\n");
            }
            
            // 3. Crear materia de prueba
            try {
                Materia materia = materiaService.crear(
                    "Programación Web", 
                    "PRW-101", 
                    profesor.getId(), 
                    "Desarrollo de Software", 
                    "Materia para aprender desarrollo web"
                );
                resultado.append("✅ Materia creada: " + materia.getNombre() + " (ID: " + materia.getId() + ")\n");
            } catch (Exception e) {
                resultado.append("⚠️ Error creando materia (puede que ya exista): " + e.getMessage() + "\n");
            }
            
            resultado.append("\n📊 RESUMEN FINAL:\n");
            resultado.append("👨‍🏫 Profesor ID: " + profesor.getId() + "\n");
            resultado.append("📧 Email: profesor@plataforma.edu\n");
            resultado.append("🔐 Password: secret\n");
            resultado.append("\n🎯 Ya puedes probar la subida de recursos en:\n");
            resultado.append("http://localhost:8082/profesor/recursos\n");
            
            return resultado.toString();
            
        } catch (Exception e) {
            return "❌ Error creando datos completos: " + e.getMessage();
        }
    }
}