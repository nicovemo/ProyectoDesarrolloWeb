package com.Plataforma.controller;

import com.Plataforma.service.BibliotecaService;
import com.Plataforma.service.RecursoService;
import com.Plataforma.service.MateriaService;
import com.Plataforma.service.UsuarioService;
import com.Plataforma.repository.ProfesorRepository;
import com.dev1.app.model.Biblioteca.Biblioteca;
import com.dev1.app.model.Biblioteca.BibliotecaRepository;
import com.dev1.app.model.Usuario.Usuario;
import com.ctp.profesores.entity.Profesor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;

import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;

@Controller
@RequestMapping("/recursos")
public class RecursoController {

    private final RecursoService recursoService;
    private final MateriaService materiaService;
    private final BibliotecaService bibliotecaService;
    private final BibliotecaRepository bibliotecaRepository;
    private final ProfesorRepository profesorRepository;
    private final UsuarioService usuarioService;
    
    public RecursoController(RecursoService recursoService, MateriaService materiaService, 
                           BibliotecaService bibliotecaService, BibliotecaRepository bibliotecaRepository,
                           ProfesorRepository profesorRepository, UsuarioService usuarioService) {
        this.recursoService = recursoService;
        this.materiaService = materiaService;
        this.bibliotecaService = bibliotecaService;
        this.bibliotecaRepository = bibliotecaRepository;
        this.profesorRepository = profesorRepository;
        this.usuarioService = usuarioService;
    }

    // === Ver todos los recursos ===
    @GetMapping
    public String listar(@RequestParam(required = false) String query, Model model) {
        model.addAttribute("recursos", recursoService.buscar(query));
        model.addAttribute("query", query);
        return "recursos/archivos";
    }

    // === Formulario subir recurso ===
    @GetMapping("/subir")
    public String formSubir(Model model) {
        model.addAttribute("materias", materiaService.listar());
        return "recursos/subir";
    }

    // === Subir archivo recurso ===
    @PostMapping("/subir")
    public String subirArchivo(
            @RequestParam Long materiaId,
            @RequestParam MultipartFile archivo,
            @RequestParam String titulo,
            @RequestParam(required = false) String descripcion,
            Model model
    ) {
        try {
            // Obtener el profesor automáticamente del usuario logueado
            Authentication auth = SecurityContextHolder.getContext().getAuthentication();
            String email = auth.getName();
            Usuario usuario = usuarioService.buscarPorEmail(email);
            
            if (usuario == null) {
                model.addAttribute("error", "Usuario no encontrado");
                model.addAttribute("materias", materiaService.listar());
                return "recursos/subir";
            }
            
            // Verificar que el usuario tenga rol de profesor
            if (!com.dev1.app.model.Usuario.Rol.PROFESOR.equals(usuario.getRol())) {
                model.addAttribute("error", "Solo los usuarios con rol de profesor pueden subir archivos");
                model.addAttribute("materias", materiaService.listar());
                return "recursos/subir";
            }
            
            // Buscar el profesor asociado al usuario, primero por ID de usuario, luego por correo
            Profesor profesor = profesorRepository.findByUsuarioId(usuario.getId()).orElse(null);
            
            // Si no lo encuentra por usuario ID, intentar por correo
            if (profesor == null) {
                profesor = profesorRepository.findByCorreo(usuario.getEmail()).orElse(null);
            }
            
            if (profesor == null) {
                model.addAttribute("error", "No se encontró el perfil de profesor asociado a su usuario. Verifique que su usuario tenga rol de profesor.");
                model.addAttribute("materias", materiaService.listar());
                return "recursos/subir";
            }
            
            Long profesorId = profesor.getId();
            
            // Validaciones básicas
            if (archivo.isEmpty()) {
                model.addAttribute("error", "Debe seleccionar un archivo");
                model.addAttribute("materias", materiaService.listar());
                return "recursos/subir";
            }
            
            if (materiaId == null) {
                model.addAttribute("error", "Debe seleccionar una materia válida");
                model.addAttribute("materias", materiaService.listar());
                return "recursos/subir";
            }
            
            recursoService.guardar(materiaId, profesorId, archivo, titulo, descripcion);
            return "redirect:/recursos?mensaje=Archivo subido exitosamente";
        } catch (IOException e) {
            model.addAttribute("error", "Error al subir el archivo: " + e.getMessage());
            model.addAttribute("materias", materiaService.listar());
            return "recursos/subir";
        } catch (RuntimeException e) {
            model.addAttribute("error", "Error: " + e.getMessage());
            model.addAttribute("materias", materiaService.listar());
            return "recursos/subir";
        } catch (Exception e) {
            model.addAttribute("error", "Error inesperado: " + e.getMessage());
            model.addAttribute("materias", materiaService.listar());
            return "recursos/subir";
        }
    }

    // === Crear recurso de enlace/libro ===
    @GetMapping("/crear")
    public String formCrear(Model model) {
        return "recursos/crear";
    }

    @PostMapping("/crear")
    public String crearRecurso(
            @RequestParam String titulo,
            @RequestParam String tipo,
            @RequestParam(required = false) String autor,
            @RequestParam(required = false) String enlace,
            @RequestParam(required = false) String descripcion
    ) {
        Biblioteca recurso = new Biblioteca();
        recurso.setTitulo(titulo);
        recurso.setTipo(tipo);
        recurso.setAutor(autor);
        recurso.setEnlace(enlace);
        recurso.setDescripcion(descripcion);

        bibliotecaRepository.save(recurso);
        return "redirect:/recursos?mensaje=Recurso creado exitosamente";
    }

    // === Eliminar recurso ===
    @PostMapping("/{id}/eliminar")
    public String eliminar(@PathVariable Long id) {
        try {
            recursoService.eliminar(id);
            return "redirect:/recursos?mensaje=Recurso eliminado exitosamente";
        } catch (Exception e) {
            return "redirect:/recursos?error=Error al eliminar recurso: " + e.getMessage();
        }
    }
    
    // === Descargar archivo ===
    @GetMapping("/descargar/{filename}")
    public ResponseEntity<Resource> descargarArchivo(@PathVariable String filename) {
        try {
            Path filePath = Paths.get("uploads").resolve(filename);
            Resource resource = new UrlResource(filePath.toUri());
            
            if (resource.exists() && resource.isReadable()) {
                // Buscar el recurso en BD para obtener el nombre original
                String originalName = recursoService.listarTodos().stream()
                    .filter(r -> filename.equals(r.getFilename()))
                    .map(r -> r.getOriginalName())
                    .findFirst()
                    .orElse(filename);
                
                return ResponseEntity.ok()
                    .contentType(MediaType.APPLICATION_OCTET_STREAM)
                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + originalName + "\"")
                    .body(resource);
            } else {
                return ResponseEntity.notFound().build();
            }
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }
}