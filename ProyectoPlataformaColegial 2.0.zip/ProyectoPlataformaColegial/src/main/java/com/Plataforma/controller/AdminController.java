/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.Plataforma.controller;

import com.Plataforma.domain.Comunicado;
import com.Plataforma.domain.EventoCalendario;
import com.Plataforma.dto.CrearUsuarioDto;
import com.Plataforma.service.AdministrativoService;
import com.Plataforma.service.ComunicadoService;
import com.Plataforma.service.EventoCalendarioService;
import com.Plataforma.service.MateriaService;
import com.dev1.app.model.Usuario.Usuario;
import com.dev1.app.model.Usuario.UsuarioRepository;
import com.dev1.app.model.Estudiante.Estudiante;
import com.Plataforma.repository.EstudianteRepository;
import com.ctp.profesores.entity.Materia;
import com.ctp.profesores.entity.Profesor;
import com.Plataforma.repository.ProfesorRepository;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import org.springframework.http.HttpStatus;

@Controller
@RequestMapping("/admin")
public class AdminController {

    private final AdministrativoService administrativoService;
    private final ComunicadoService comunicadoService;
    private final EventoCalendarioService eventoService;
    private final UsuarioRepository usuarioRepository;
    private final EstudianteRepository estudianteRepository;
    private final ProfesorRepository profesorRepository;
    private final MateriaService materiaService;
    private final PasswordEncoder passwordEncoder;
    
    public AdminController(AdministrativoService administrativoService,
                          ComunicadoService comunicadoService,
                          EventoCalendarioService eventoService,
                          UsuarioRepository usuarioRepository,
                          EstudianteRepository estudianteRepository,
                          ProfesorRepository profesorRepository,
                          MateriaService materiaService,
                          PasswordEncoder passwordEncoder) {
        this.administrativoService = administrativoService;
        this.comunicadoService = comunicadoService;
        this.eventoService = eventoService;
        this.usuarioRepository = usuarioRepository;
        this.estudianteRepository = estudianteRepository;
        this.profesorRepository = profesorRepository;
        this.materiaService = materiaService;
        this.passwordEncoder = passwordEncoder;
    }

    // === Dashboard ===
    @GetMapping({"", "/", "/dashboard"})
    public String dashboard(Model model) {
        model.addAttribute("totalUsuarios", usuarioRepository.count());
        model.addAttribute("totalEstudiantes", estudianteRepository.count());
        model.addAttribute("totalProfesores", profesorRepository.count());
        model.addAttribute("totalAdministrativos", administrativoService.listar().size());
        model.addAttribute("totalMaterias", materiaService.listar().size());
        model.addAttribute("totalComunicados", comunicadoService.listarTodos().size());
        return "admin/dashboard";
    }

    // === Usuarios ===
    @GetMapping("/usuarios")
    public String usuarios(Model model) {
        model.addAttribute("estudiantes", estudianteRepository.findAll());
        model.addAttribute("profesores", profesorRepository.findAll());
        model.addAttribute("administrativos", administrativoService.listar());
        return "admin/usuarios";
    }

    @PostMapping("/usuarios")
    public String crearUsuario(CrearUsuarioDto dto, RedirectAttributes redirectAttributes) {
        try {
            // Crear usuario base
            Usuario usuario = new Usuario();
            usuario.setNombre(dto.getNombre());
            usuario.setApellido(dto.getApellido());
            usuario.setEmail(dto.getEmail());
            usuario.setPassword(passwordEncoder.encode(dto.getPassword()));
            usuario.setTipoUsuario(dto.getTipoUsuario());
            usuario.setActivo(true);
            
            // Generar username único basado en email
            String baseUsername = dto.getEmail().split("@")[0].toLowerCase().replaceAll("[^a-z0-9]", "");
            if (baseUsername.length() < 3) {
                baseUsername = dto.getNombre().toLowerCase().replaceAll("[^a-z0-9]", "").substring(0, Math.min(3, dto.getNombre().length()));
            }
            
            // Asegurar que el username sea único
            String finalUsername = baseUsername;
            int counter = 1;
            while (usuarioRepository.findByUsername(finalUsername).isPresent()) {
                finalUsername = baseUsername + counter++;
            }
            usuario.setUsername(finalUsername);
            
            Usuario usuarioGuardado = usuarioRepository.save(usuario);

            // Crear entidad específica según el tipo
            switch (dto.getTipoUsuario()) {
                case "ESTUDIANTE":
                    Estudiante estudiante = new Estudiante();
                    // NO establecer ID manualmente - se deriva del Usuario con @MapsId
                    estudiante.setUsuario(usuarioGuardado);
                    estudiante.setCedula(dto.getCedula());
                    estudiante.setTelefono(dto.getTelefono());
                    estudiante.setMatricula(dto.getMatricula());
                    estudiante.setCarrera(dto.getCarrera());
                    estudiante.setNivel(dto.getNivel());
                    estudiante.setTransporteBeca(dto.isTransporteBeca());
                    estudiante.setComedorBeca(dto.isComedorBeca());
                    estudianteRepository.save(estudiante);
                    break;
                    
                case "PROFESOR":
                    Profesor profesor = new Profesor();
                    profesor.setUsuario(usuarioGuardado);
                    profesor.setCedula(dto.getCedula());
                    profesor.setTelefono(dto.getTelefono());
                    profesor.setEspecialidad(dto.getEspecialidad());
                    profesor.setNombre(dto.getNombre() + " " + dto.getApellido());
                    profesor.setCorreo(dto.getEmail());
                    profesor.setPasswordHash(passwordEncoder.encode(dto.getPassword()));
                    profesor.setActivo(true);
                    profesorRepository.save(profesor);
                    break;
                    
                case "ADMINISTRATIVO":
                    administrativoService.crearDesdeUsuario(usuarioGuardado.getId(), dto.getPuesto(), dto.getDepartamento());
                    break;
            }
            
            redirectAttributes.addFlashAttribute("mensaje", "Usuario creado exitosamente");
            redirectAttributes.addFlashAttribute("tipoMensaje", "success");
            
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("mensaje", "Error al crear usuario: " + e.getMessage());
            redirectAttributes.addFlashAttribute("tipoMensaje", "danger");
        }
        
        return "redirect:/admin/usuarios";
    }

    @PostMapping("/usuarios/administrativo")
    public String crearAdministrativo(
            @RequestParam Long usuarioId,
            @RequestParam String puesto,
            @RequestParam String departamento
    ) {
        administrativoService.crearDesdeUsuario(usuarioId, puesto, departamento);
        return "redirect:/admin/usuarios";
    }

    // === Materias (CRUD) ===
    @GetMapping("/materias")
    public String materias(Model model) {
        model.addAttribute("materias", materiaService.listar());
        model.addAttribute("profesores", profesorRepository.findAll());
        model.addAttribute("materiaForm", new Materia());
        return "admin/materias";
    }

    @PostMapping("/materias")
    public String crearMateria(
            @RequestParam String nombre,
            @RequestParam String codigo,
            @RequestParam Long profesorId,
            @RequestParam(required = false) String especialidad,
            @RequestParam(required = false) String descripcion,
            RedirectAttributes redirectAttributes
    ) {
        try {
            materiaService.crear(nombre, codigo, profesorId, especialidad, descripcion);
            redirectAttributes.addFlashAttribute("mensaje", "Materia creada exitosamente");
            redirectAttributes.addFlashAttribute("tipo", "success");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("mensaje", "Error al crear materia: " + e.getMessage());
            redirectAttributes.addFlashAttribute("tipo", "error");
        }
        return "redirect:/admin/materias";
    }

    @GetMapping("/materias/{id}/datos")
    @ResponseBody
    public ResponseEntity<Map<String, Object>> obtenerDatosMateria(@PathVariable Long id) {
        try {
            Materia materia = materiaService.buscarPorId(id);
            Map<String, Object> datos = new HashMap<>();
            datos.put("id", materia.getId());
            datos.put("nombre", materia.getNombre());
            datos.put("codigo", materia.getCodigo());
            datos.put("profesorId", materia.getProfesor().getId());
            datos.put("especialidad", materia.getEspecialidad());
            datos.put("descripcion", materia.getDescripcion());
            return ResponseEntity.ok(datos);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(Map.of("error", "Materia no encontrada"));
        }
    }

    @PostMapping("/materias/{id}/actualizar")
    public String actualizarMateria(
            @PathVariable Long id,
            @RequestParam String nombre,
            @RequestParam String codigo,
            @RequestParam Long profesorId,
            @RequestParam(required = false) String especialidad,
            @RequestParam(required = false) String descripcion,
            RedirectAttributes redirectAttributes
    ) {
        try {
            materiaService.actualizar(id, nombre, codigo, profesorId, especialidad, descripcion);
            redirectAttributes.addFlashAttribute("mensaje", "Materia actualizada exitosamente");
            redirectAttributes.addFlashAttribute("tipo", "success");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("mensaje", "Error al actualizar materia: " + e.getMessage());
            redirectAttributes.addFlashAttribute("tipo", "error");
        }
        return "redirect:/admin/materias";
    }

    @PostMapping("/materias/{id}/eliminar")
    public String eliminarMateria(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        try {
            materiaService.eliminar(id);
            redirectAttributes.addFlashAttribute("mensaje", "Materia eliminada exitosamente");
            redirectAttributes.addFlashAttribute("tipo", "success");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("mensaje", "Error al eliminar materia: " + e.getMessage());
            redirectAttributes.addFlashAttribute("tipo", "error");
        }
        return "redirect:/admin/materias";
    }
    
    // === Usuarios CRUD ===
    @PostMapping("/usuarios/estudiante")
    public String crearEstudiante(
            @RequestParam String nombre,
            @RequestParam String apellido,
            @RequestParam String email,
            @RequestParam String password,
            @RequestParam String cedula,
            @RequestParam String telefono,
            @RequestParam String carrera,
            @RequestParam Integer nivel,
            RedirectAttributes redirectAttributes
    ) {
        try {
            // Crear usuario primero
            Usuario usuario = new Usuario();
            usuario.setNombre(nombre);
            usuario.setApellido(apellido);
            usuario.setEmail(email);
            usuario.setPassword(passwordEncoder.encode(password));
            usuario.setTipoUsuario("ESTUDIANTE");
            usuario.setActivo(true);
            Usuario usuarioGuardado = usuarioRepository.save(usuario);

            // Crear estudiante
            Estudiante estudiante = new Estudiante();
            estudiante.setUsuario(usuarioGuardado);
            estudiante.setCedula(cedula);
            estudiante.setTelefono(telefono);
            estudiante.setCarrera(carrera);
            estudiante.setNivel(nivel);
            estudianteRepository.save(estudiante);

            redirectAttributes.addFlashAttribute("mensaje", "Estudiante creado exitosamente");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error al crear estudiante: " + e.getMessage());
        }
        return "redirect:/admin/usuarios";
    }

    @PostMapping("/usuarios/profesor")
    public String crearProfesor(
            @RequestParam String nombre,
            @RequestParam String apellido,
            @RequestParam String email,
            @RequestParam String password,
            @RequestParam String cedula,
            @RequestParam String telefono,
            @RequestParam String especialidad,
            RedirectAttributes redirectAttributes
    ) {
        try {
            // Crear usuario primero
            Usuario usuario = new Usuario();
            usuario.setNombre(nombre);
            usuario.setApellido(apellido);
            usuario.setEmail(email);
            usuario.setPassword(passwordEncoder.encode(password));
            usuario.setTipoUsuario("PROFESOR");
            usuario.setActivo(true);
            Usuario usuarioGuardado = usuarioRepository.save(usuario);

            // Crear profesor
            Profesor profesor = new Profesor();
            profesor.setUsuario(usuarioGuardado);
            profesor.setCedula(cedula);
            profesor.setTelefono(telefono);
            profesor.setEspecialidad(especialidad);
            profesorRepository.save(profesor);

            redirectAttributes.addFlashAttribute("mensaje", "Profesor creado exitosamente");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error al crear profesor: " + e.getMessage());
        }
        return "redirect:/admin/usuarios";
    }

    @PostMapping("/usuarios/{id}/toggle")
    public String toggleUsuario(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        try {
            Usuario usuario = usuarioRepository.findById(id)
                    .orElseThrow(() -> new IllegalArgumentException("Usuario no encontrado"));
            usuario.setActivo(!usuario.getActivo());
            usuarioRepository.save(usuario);
            redirectAttributes.addFlashAttribute("mensaje", "Estado del usuario actualizado");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error al cambiar estado: " + e.getMessage());
        }
        return "redirect:/admin/usuarios";
    }

    @PostMapping("/usuarios/{id}/eliminar")
    @ResponseBody
    public ResponseEntity<?> eliminarUsuario(@PathVariable Long id) {
        try {
            Optional<Usuario> usuarioOpt = usuarioRepository.findById(id);
            if (usuarioOpt.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(Map.of("error", "Usuario no encontrado"));
            }
            
            Usuario usuario = usuarioOpt.get();
            
            // Verificar si el usuario tiene registros dependientes
            // Si es profesor, verificar si tiene materias asignadas
            if ("PROFESOR".equals(usuario.getRol().toString())) {
                // Aquí podrías agregar lógica para verificar materias asignadas
                // Por ahora, eliminamos las referencias antes de eliminar el usuario
                profesorRepository.findAll().stream()
                    .filter(p -> p.getUsuario() != null && p.getUsuario().getId().equals(id))
                    .forEach(p -> profesorRepository.delete(p));
            }
            
            // Si es administrativo, eliminar registro administrativo primero
            if ("ADMINISTRATIVO".equals(usuario.getRol().toString())) {
                administrativoService.buscarPorUsuarioId(id).ifPresent(admin -> {
                    administrativoService.eliminar(admin.getId());
                });
            }
            
            // Si es estudiante, eliminar registro de estudiante primero
            if ("ESTUDIANTE".equals(usuario.getRol().toString())) {
                estudianteRepository.findAll().stream()
                    .filter(e -> e.getId().equals(id))
                    .forEach(e -> estudianteRepository.delete(e));
            }
            
            // Finalmente eliminar el usuario
            usuarioRepository.deleteById(id);
            return ResponseEntity.ok(Map.of("mensaje", "Usuario eliminado exitosamente"));
            
        } catch (org.springframework.dao.DataIntegrityViolationException e) {
            String mensaje = "No se puede eliminar el usuario porque tiene registros asociados. ";
            if (e.getMessage().contains("profesor")) {
                mensaje += "El profesor tiene materias asignadas.";
            } else if (e.getMessage().contains("administrativo")) {
                mensaje += "El administrativo tiene registros dependientes.";
            } else {
                mensaje += "Existen registros que dependen de este usuario.";
            }
            return ResponseEntity.status(HttpStatus.CONFLICT)
                .body(Map.of("error", mensaje));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(Map.of("error", "Error al eliminar usuario: " + e.getMessage()));
        }
    }
    
    @GetMapping("/usuarios/{id}/datos")
    @ResponseBody
    public ResponseEntity<?> obtenerDatosUsuario(@PathVariable Long id) {
        try {
            Optional<Usuario> usuarioOpt = usuarioRepository.findById(id);
            if (usuarioOpt.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(Map.of("error", "Usuario no encontrado con ID: " + id));
            }
            
            Usuario usuario = usuarioOpt.get();
            Map<String, Object> datos = new HashMap<>();
            datos.put("id", usuario.getId());
            datos.put("nombre", usuario.getNombre() != null ? usuario.getNombre() : "");
            datos.put("apellido", usuario.getApellido() != null ? usuario.getApellido() : "");
            datos.put("email", usuario.getEmail() != null ? usuario.getEmail() : "");
            datos.put("username", usuario.getUsername() != null ? usuario.getUsername() : "");
            datos.put("activo", usuario.getActivo() != null ? usuario.getActivo() : false);
            
            String rolString = usuario.getRol() != null ? usuario.getRol().toString() : "ESTUDIANTE";
            datos.put("rol", rolString);
            
            // Agregar datos específicos según el rol
            if ("ESTUDIANTE".equals(rolString)) {
                estudianteRepository.findById(id).ifPresent(estudiante -> {
                    Map<String, Object> datosEstudiante = new HashMap<>();
                    datosEstudiante.put("cedula", estudiante.getCedula() != null ? estudiante.getCedula() : "");
                    datosEstudiante.put("telefono", estudiante.getTelefono() != null ? estudiante.getTelefono() : "");
                    datosEstudiante.put("carrera", estudiante.getCarrera() != null ? estudiante.getCarrera() : "");
                    datosEstudiante.put("nivel", estudiante.getNivel() != null ? estudiante.getNivel() : 1);
                    datosEstudiante.put("matricula", estudiante.getMatricula() != null ? estudiante.getMatricula() : "");
                    datosEstudiante.put("transporteBeca", estudiante.getTransporteBeca() != null ? estudiante.getTransporteBeca() : false);
                    datosEstudiante.put("comedorBeca", estudiante.getComedorBeca() != null ? estudiante.getComedorBeca() : false);
                    datos.put("estudiante", datosEstudiante);
                });
            } else if ("PROFESOR".equals(rolString)) {
                profesorRepository.findAll().stream()
                    .filter(p -> p.getUsuario() != null && p.getUsuario().getId().equals(id))
                    .findFirst()
                    .ifPresent(profesor -> {
                        Map<String, Object> datosProfesor = new HashMap<>();
                        datosProfesor.put("cedula", profesor.getCedula() != null ? profesor.getCedula() : "");
                        datosProfesor.put("especialidad", profesor.getEspecialidad() != null ? profesor.getEspecialidad() : "");
                        datosProfesor.put("telefono", profesor.getTelefono() != null ? profesor.getTelefono() : "");
                        datosProfesor.put("correo", profesor.getCorreo() != null ? profesor.getCorreo() : "");
                        datos.put("profesor", datosProfesor);
                    });
            } else if ("ADMINISTRATIVO".equals(rolString)) {
                administrativoService.buscarPorUsuarioId(id).ifPresent(admin -> {
                    Map<String, Object> datosAdmin = new HashMap<>();
                    datosAdmin.put("cedula", ""); // Los administrativos no tienen cedula en la base de datos
                    datosAdmin.put("puesto", admin.getPuesto() != null ? admin.getPuesto() : "");
                    datosAdmin.put("departamento", admin.getDepartamento() != null ? admin.getDepartamento() : "");
                    datos.put("administrativo", datosAdmin);
                });
            }
            
            return ResponseEntity.ok(datos);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(Map.of("error", "Error al obtener datos del usuario: " + e.getMessage()));
        }
    }

    @PostMapping("/usuarios/{id}/actualizar")
    @ResponseBody
    public ResponseEntity<?> actualizarUsuario(@PathVariable Long id, @RequestBody Map<String, Object> datos) {
        try {
            Optional<Usuario> usuarioOpt = usuarioRepository.findById(id);
            if (usuarioOpt.isEmpty()) {
                return ResponseEntity.notFound().build();
            }
            
            Usuario usuario = usuarioOpt.get();
            
            // Asegurar que el rol no sea null
            if (usuario.getRol() == null) {
                // Determinar el rol basado en datos existentes
                if (datos.containsKey("tipoUsuario")) {
                    usuario.setTipoUsuario((String) datos.get("tipoUsuario"));
                } else {
                    usuario.setTipoUsuario("ESTUDIANTE"); // valor por defecto
                }
            }
            
            // Actualizar datos básicos del usuario
            if (datos.containsKey("nombre")) {
                usuario.setNombre((String) datos.get("nombre"));
            }
            if (datos.containsKey("apellido")) {
                usuario.setApellido((String) datos.get("apellido"));
            }
            if (datos.containsKey("email")) {
                usuario.setEmail((String) datos.get("email"));
            }
            if (datos.containsKey("password") && !((String) datos.get("password")).trim().isEmpty()) {
                usuario.setPassword(passwordEncoder.encode((String) datos.get("password")));
            }
            
            usuarioRepository.save(usuario);
            
            // Actualizar datos específicos según el rol
            String rolActual = usuario.getRol() != null ? usuario.getRol().toString() : "ESTUDIANTE";
            if ("ESTUDIANTE".equals(rolActual) && datos.containsKey("estudiante")) {
                estudianteRepository.findById(id).ifPresent(estudiante -> {
                    Map<String, Object> datosEstudiante = (Map<String, Object>) datos.get("estudiante");
                    if (datosEstudiante.containsKey("cedula")) {
                        estudiante.setCedula((String) datosEstudiante.get("cedula"));
                    }
                    if (datosEstudiante.containsKey("telefono")) {
                        estudiante.setTelefono((String) datosEstudiante.get("telefono"));
                    }
                    if (datosEstudiante.containsKey("carrera")) {
                        estudiante.setCarrera((String) datosEstudiante.get("carrera"));
                    }
                    if (datosEstudiante.containsKey("nivel")) {
                        estudiante.setNivel((Integer) datosEstudiante.get("nivel"));
                    }
                    estudianteRepository.save(estudiante);
                });
            } else if ("PROFESOR".equals(rolActual) && datos.containsKey("profesor")) {
                profesorRepository.findAll().stream()
                    .filter(p -> p.getUsuario() != null && p.getUsuario().getId().equals(id))
                    .findFirst()
                    .ifPresent(profesor -> {
                        Map<String, Object> datosProfesor = (Map<String, Object>) datos.get("profesor");
                        if (datosProfesor.containsKey("cedula")) {
                            profesor.setCedula((String) datosProfesor.get("cedula"));
                        }
                        if (datosProfesor.containsKey("especialidad")) {
                            profesor.setEspecialidad((String) datosProfesor.get("especialidad"));
                        }
                        if (datosProfesor.containsKey("telefono")) {
                            profesor.setTelefono((String) datosProfesor.get("telefono"));
                        }
                        profesorRepository.save(profesor);
                    });
            } else if ("ADMINISTRATIVO".equals(rolActual) && datos.containsKey("administrativo")) {
                administrativoService.buscarPorUsuarioId(id).ifPresent(admin -> {
                    Map<String, Object> datosAdmin = (Map<String, Object>) datos.get("administrativo");
                    if (datosAdmin.containsKey("puesto")) {
                        admin.setPuesto((String) datosAdmin.get("puesto"));
                    }
                    if (datosAdmin.containsKey("departamento")) {
                        admin.setDepartamento((String) datosAdmin.get("departamento"));
                    }
                    administrativoService.guardar(admin);
                });
            }
            
            return ResponseEntity.ok(Map.of("mensaje", "Usuario actualizado exitosamente"));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(Map.of("error", "Error al actualizar usuario: " + e.getMessage()));
        }
    }

    // === Comunicados ===
    @GetMapping("/comunicados")
    public String comunicados(Model model) {
        model.addAttribute("comunicados", comunicadoService.listarTodos());
        model.addAttribute("totalPublicados", comunicadoService.contarPorEstado(Comunicado.Estado.PUBLICADO));
        model.addAttribute("totalBorradores", comunicadoService.contarPorEstado(Comunicado.Estado.BORRADOR));
        model.addAttribute("comunicadosImportantes", comunicadoService.listarImportantes());
        return "admin/comunicados";
    }
    
    @PostMapping("/comunicados")
    public String crearComunicado(
            @RequestParam String titulo,
            @RequestParam String contenido,
            @RequestParam Comunicado.Prioridad prioridad,
            @RequestParam Comunicado.Estado estado,
            @RequestParam String dirigidoA,
            @RequestParam(required = false) @DateTimeFormat(pattern = "yyyy-MM-dd'T'HH:mm") LocalDateTime fechaPublicacion,
            @RequestParam(required = false) @DateTimeFormat(pattern = "yyyy-MM-dd'T'HH:mm") LocalDateTime fechaVencimiento,
            @RequestParam(required = false) Boolean esImportante,
            @RequestParam(required = false) Boolean permitirComentarios,
            Authentication authentication,
            RedirectAttributes redirectAttributes
    ) {
        try {
            Comunicado comunicado = new Comunicado();
            comunicado.setTitulo(titulo);
            comunicado.setContenido(contenido);
            comunicado.setPrioridad(prioridad);
            comunicado.setEstado(estado);
            comunicado.setDirigidoA(dirigidoA);
            comunicado.setFechaPublicacion(fechaPublicacion);
            comunicado.setFechaVencimiento(fechaVencimiento);
            comunicado.setEsImportante(esImportante != null ? esImportante : false);
            comunicado.setPermitirComentarios(permitirComentarios != null ? permitirComentarios : true);

            comunicadoService.crear(comunicado, authentication.getName());
            redirectAttributes.addFlashAttribute("mensaje", "Comunicado creado exitosamente");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error al crear comunicado: " + e.getMessage());
        }
        return "redirect:/admin/comunicados";
    }

    @PostMapping("/comunicados/{id}/publicar")
    public String publicarComunicado(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        try {
            comunicadoService.publicar(id);
            redirectAttributes.addFlashAttribute("mensaje", "Comunicado publicado exitosamente");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error al publicar: " + e.getMessage());
        }
        return "redirect:/admin/comunicados";
    }

    @PostMapping("/comunicados/{id}/archivar")
    public String archivarComunicado(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        try {
            comunicadoService.archivar(id);
            redirectAttributes.addFlashAttribute("mensaje", "Comunicado archivado exitosamente");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error al archivar: " + e.getMessage());
        }
        return "redirect:/admin/comunicados";
    }

    @GetMapping("/comunicados/{id}/datos")
    @ResponseBody
    public ResponseEntity<Map<String, Object>> obtenerDatosComunicado(@PathVariable Long id) {
        try {
            Comunicado comunicado = comunicadoService.buscarPorId(id);
            Map<String, Object> datos = new HashMap<>();
            datos.put("id", comunicado.getId());
            datos.put("titulo", comunicado.getTitulo());
            datos.put("contenido", comunicado.getContenido());
            datos.put("prioridad", comunicado.getPrioridad().name());
            datos.put("estado", comunicado.getEstado().name());
            datos.put("dirigidoA", comunicado.getDirigidoA());
            datos.put("fechaPublicacion", comunicado.getFechaPublicacion());
            datos.put("fechaVencimiento", comunicado.getFechaVencimiento());
            datos.put("esImportante", comunicado.getEsImportante());
            datos.put("permitirComentarios", comunicado.getPermitirComentarios());
            return ResponseEntity.ok(datos);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(Map.of("error", "Comunicado no encontrado"));
        }
    }

    @PostMapping("/comunicados/{id}/actualizar")
    public String actualizarComunicado(
            @PathVariable Long id,
            @RequestParam String titulo,
            @RequestParam String contenido,
            @RequestParam Comunicado.Prioridad prioridad,
            @RequestParam Comunicado.Estado estado,
            @RequestParam String dirigidoA,
            @RequestParam(required = false) @DateTimeFormat(pattern = "yyyy-MM-dd'T'HH:mm") LocalDateTime fechaPublicacion,
            @RequestParam(required = false) @DateTimeFormat(pattern = "yyyy-MM-dd'T'HH:mm") LocalDateTime fechaVencimiento,
            @RequestParam(required = false) Boolean esImportante,
            @RequestParam(required = false) Boolean permitirComentarios,
            RedirectAttributes redirectAttributes
    ) {
        try {
            Comunicado comunicadoActualizado = new Comunicado();
            comunicadoActualizado.setTitulo(titulo);
            comunicadoActualizado.setContenido(contenido);
            comunicadoActualizado.setPrioridad(prioridad);
            comunicadoActualizado.setEstado(estado);
            comunicadoActualizado.setDirigidoA(dirigidoA);
            comunicadoActualizado.setFechaPublicacion(fechaPublicacion);
            comunicadoActualizado.setFechaVencimiento(fechaVencimiento);
            comunicadoActualizado.setEsImportante(esImportante != null ? esImportante : false);
            comunicadoActualizado.setPermitirComentarios(permitirComentarios != null ? permitirComentarios : true);

            comunicadoService.actualizar(id, comunicadoActualizado);
            redirectAttributes.addFlashAttribute("mensaje", "Comunicado actualizado exitosamente");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error al actualizar comunicado: " + e.getMessage());
        }
        return "redirect:/admin/comunicados";
    }

    @PostMapping("/comunicados/{id}/eliminar")
    public String eliminarComunicado(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        try {
            comunicadoService.eliminar(id);
            redirectAttributes.addFlashAttribute("mensaje", "Comunicado eliminado exitosamente");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error al eliminar: " + e.getMessage());
        }
        return "redirect:/admin/comunicados";
    }
    
    // === Calendario ===
    @GetMapping("/calendario")
    public String calendario(Model model) {
        LocalDateTime inicioMes = LocalDateTime.now().withDayOfMonth(1).withHour(0).withMinute(0).withSecond(0);
        LocalDateTime finMes = inicioMes.plusMonths(1).minusDays(1).withHour(23).withMinute(59).withSecond(59);
        
        model.addAttribute("eventos", eventoService.listarTodos());
        model.addAttribute("eventosMes", eventoService.listarPorRangoFechas(inicioMes, finMes));
        model.addAttribute("proximosEventos", eventoService.obtenerProximosEventos());
        model.addAttribute("totalEventos", eventoService.contarPorEstado(EventoCalendario.EstadoEvento.PROGRAMADO));
        model.addAttribute("totalEventosCompletados", eventoService.contarPorEstado(EventoCalendario.EstadoEvento.COMPLETADO));
        model.addAttribute("totalEventosCancelados", eventoService.contarPorEstado(EventoCalendario.EstadoEvento.CANCELADO));
        model.addAttribute("mesActual", LocalDateTime.now().getMonth().toString());
        model.addAttribute("añoActual", LocalDateTime.now().getYear());
        return "admin/calendario";
    }

    @GetMapping("/calendario/eventos/{año}/{mes}")
    @ResponseBody
    public ResponseEntity<Map<String, Object>> obtenerEventosDelMes(@PathVariable int año, @PathVariable int mes) {
        Map<String, Object> response = new HashMap<>();
        try {
            response.put("eventos", eventoService.obtenerEventosDelMes(año, mes));
            response.put("success", true);
        } catch (Exception e) {
            response.put("success", false);
            response.put("error", e.getMessage());
        }
        return ResponseEntity.ok(response);
    }
    
    @PostMapping("/calendario/eventos")
    public String crearEvento(
            @RequestParam String titulo,
            @RequestParam EventoCalendario.TipoEvento tipo,
            @RequestParam @DateTimeFormat(pattern = "yyyy-MM-dd'T'HH:mm") LocalDateTime fechaInicio,
            @RequestParam(required = false) @DateTimeFormat(pattern = "yyyy-MM-dd'T'HH:mm") LocalDateTime fechaFin,
            @RequestParam(required = false) String descripcion,
            @RequestParam(required = false) String ubicacion,
            @RequestParam(required = false) String organizador,
            @RequestParam String participantesObjetivo,
            @RequestParam(required = false) String color,
            @RequestParam(required = false) Boolean esTodoElDia,
            @RequestParam(required = false) Boolean esPublico,
            @RequestParam(required = false) Boolean requiereConfirmacion,
            @RequestParam(required = false) Integer limiteParticipantes,
            @RequestParam(required = false) String enlaceExterno,
            Authentication authentication,
            RedirectAttributes redirectAttributes
    ) {
        try {
            EventoCalendario evento = new EventoCalendario();
            evento.setTitulo(titulo);
            evento.setTipo(tipo);
            evento.setFechaInicio(fechaInicio);
            evento.setFechaFin(fechaFin);
            evento.setDescripcion(descripcion);
            evento.setUbicacion(ubicacion);
            evento.setOrganizador(organizador);
            evento.setParticipantesObjetivo(participantesObjetivo);
            evento.setColor(color);
            evento.setEsTodoElDia(esTodoElDia != null ? esTodoElDia : false);
            evento.setEsPublico(esPublico != null ? esPublico : true);
            evento.setRequiereConfirmacion(requiereConfirmacion != null ? requiereConfirmacion : false);
            evento.setLimiteParticipantes(limiteParticipantes);
            evento.setEnlaceExterno(enlaceExterno);

            eventoService.crear(evento, authentication.getName());
            redirectAttributes.addFlashAttribute("mensaje", "Evento creado exitosamente");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error al crear evento: " + e.getMessage());
        }
        return "redirect:/admin/calendario";
    }

    @PostMapping("/calendario/eventos/{id}/cancelar")
    public String cancelarEvento(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        try {
            eventoService.cancelar(id);
            redirectAttributes.addFlashAttribute("mensaje", "Evento cancelado exitosamente");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error al cancelar: " + e.getMessage());
        }
        return "redirect:/admin/calendario";
    }

    @PostMapping("/calendario/eventos/{id}/completar")
    public String completarEvento(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        try {
            eventoService.completar(id);
            redirectAttributes.addFlashAttribute("mensaje", "Evento marcado como completado");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error al completar: " + e.getMessage());
        }
        return "redirect:/admin/calendario";
    }

    @PostMapping("/calendario/eventos/{id}/eliminar")
    public String eliminarEvento(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        try {
            eventoService.eliminar(id);
            redirectAttributes.addFlashAttribute("mensaje", "Evento eliminado exitosamente");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error al eliminar: " + e.getMessage());
        }
        return "redirect:/admin/calendario";
    }

    @GetMapping("/calendario/eventos/{id}/datos")
    @ResponseBody
    public ResponseEntity<?> obtenerDatosEvento(@PathVariable Long id) {
        try {
            EventoCalendario evento = eventoService.buscarPorId(id);
            return ResponseEntity.ok(evento);
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    @PostMapping("/calendario/eventos/{id}/actualizar")
    public String actualizarEvento(
            @PathVariable Long id,
            @RequestParam String titulo,
            @RequestParam EventoCalendario.TipoEvento tipo,
            @RequestParam @DateTimeFormat(pattern = "yyyy-MM-dd'T'HH:mm") LocalDateTime fechaInicio,
            @RequestParam(required = false) @DateTimeFormat(pattern = "yyyy-MM-dd'T'HH:mm") LocalDateTime fechaFin,
            @RequestParam(required = false) String descripcion,
            @RequestParam(required = false) String ubicacion,
            @RequestParam(required = false) String organizador,
            @RequestParam String participantesObjetivo,
            @RequestParam(required = false) String color,
            @RequestParam(required = false) Boolean esTodoElDia,
            @RequestParam(required = false) Boolean esPublico,
            @RequestParam(required = false) Boolean requiereConfirmacion,
            @RequestParam(required = false) Integer limiteParticipantes,
            @RequestParam(required = false) String enlaceExterno,
            Authentication authentication,
            RedirectAttributes redirectAttributes
    ) {
        try {
            EventoCalendario evento = eventoService.buscarPorId(id);
            evento.setTitulo(titulo);
            evento.setTipo(tipo);
            evento.setFechaInicio(fechaInicio);
            evento.setFechaFin(fechaFin);
            evento.setDescripcion(descripcion);
            evento.setUbicacion(ubicacion);
            evento.setOrganizador(organizador);
            evento.setParticipantesObjetivo(participantesObjetivo);
            evento.setColor(color);
            evento.setEsTodoElDia(esTodoElDia != null ? esTodoElDia : false);
            evento.setEsPublico(esPublico != null ? esPublico : true);
            evento.setRequiereConfirmacion(requiereConfirmacion != null ? requiereConfirmacion : false);
            evento.setLimiteParticipantes(limiteParticipantes);
            evento.setEnlaceExterno(enlaceExterno);

            eventoService.actualizar(id, evento);
            redirectAttributes.addFlashAttribute("mensaje", "Evento actualizado exitosamente");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error al actualizar evento: " + e.getMessage());
        }
        return "redirect:/admin/calendario";
    }
}