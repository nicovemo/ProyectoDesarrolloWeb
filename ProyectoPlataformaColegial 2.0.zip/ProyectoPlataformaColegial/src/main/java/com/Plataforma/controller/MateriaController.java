package com.Plataforma.controller;

import com.Plataforma.service.MateriaService;
import com.Plataforma.service.UsuarioService;
import com.Plataforma.repository.ProfesorRepository;
import com.ctp.profesores.entity.Profesor;
import com.dev1.app.model.Usuario.Usuario;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

@Controller
@RequestMapping("/admin/materias-profesor")
public class MateriaController {

    private final MateriaService service;
    private final UsuarioService usuarioService;
    private final ProfesorRepository profesorRepository;
    
    public MateriaController(MateriaService service, UsuarioService usuarioService, ProfesorRepository profesorRepository) {
        this.service = service;
        this.usuarioService = usuarioService;
        this.profesorRepository = profesorRepository;
    }

    @GetMapping
    public String listar(Model model) {
        try {
            // Obtener el profesor automáticamente del usuario logueado
            Authentication auth = SecurityContextHolder.getContext().getAuthentication();
            String email = auth.getName();
            Usuario usuario = usuarioService.buscarPorEmail(email);
            
            if (usuario != null) {
                // Verificar que el usuario tenga rol de profesor
                if (!com.dev1.app.model.Usuario.Rol.PROFESOR.equals(usuario.getRol())) {
                    model.addAttribute("materias", java.util.Collections.emptyList());
                    model.addAttribute("error", "Solo los usuarios con rol de profesor pueden acceder a esta sección");
                    return "profesor/materias/list";
                }
                
                // Buscar el profesor asociado al usuario, primero por ID de usuario, luego por correo
                Profesor profesor = profesorRepository.findByUsuarioId(usuario.getId()).orElse(null);
                
                // Si no lo encuentra por usuario ID, intentar por correo
                if (profesor == null) {
                    profesor = profesorRepository.findByCorreo(usuario.getEmail()).orElse(null);
                }
                
                if (profesor != null) {
                    model.addAttribute("materias", service.listar(profesor.getId()));
                } else {
                    model.addAttribute("materias", java.util.Collections.emptyList());
                    model.addAttribute("error", "No se encontró el perfil de profesor asociado. Verifique que su usuario tenga rol de profesor.");
                }
            } else {
                model.addAttribute("materias", java.util.Collections.emptyList());
                model.addAttribute("error", "Usuario no encontrado");
            }
        } catch (Exception e) {
            model.addAttribute("materias", java.util.Collections.emptyList());
            model.addAttribute("error", "Error al cargar las materias: " + e.getMessage());
        }
        return "profesor/materias/list";
    }

    @PostMapping("/crear")
    public String crearMateria(
            @RequestParam String nombre,
            @RequestParam String codigo,
            @RequestParam(required = false) String especialidad,
            @RequestParam(required = false) String descripcion,
            Model model
    ) {
        try {
            // Obtener el profesor automáticamente del usuario logueado
            Authentication auth = SecurityContextHolder.getContext().getAuthentication();
            String email = auth.getName();
            Usuario usuario = usuarioService.buscarPorEmail(email);
            
            if (usuario == null) {
                model.addAttribute("error", "Usuario no encontrado");
                return "redirect:/admin/materias-profesor?error=Usuario no encontrado";
            }
            
            // Verificar que el usuario tenga rol de profesor
            if (!com.dev1.app.model.Usuario.Rol.PROFESOR.equals(usuario.getRol())) {
                return "redirect:/admin/materias-profesor?error=Solo los usuarios con rol de profesor pueden crear materias";
            }
            
            // Buscar el profesor asociado al usuario, primero por ID de usuario, luego por correo
            Profesor profesor = profesorRepository.findByUsuarioId(usuario.getId()).orElse(null);
            
            // Si no lo encuentra por usuario ID, intentar por correo
            if (profesor == null) {
                profesor = profesorRepository.findByCorreo(usuario.getEmail()).orElse(null);
            }
            
            if (profesor == null) {
                model.addAttribute("error", "No se encontró el perfil de profesor asociado. Verifique que su usuario tenga rol de profesor.");
                return "redirect:/admin/materias-profesor?error=Profesor no encontrado";
            }
            
            service.crear(nombre, codigo, profesor.getId(), especialidad, descripcion);
            return "redirect:/admin/materias-profesor?mensaje=Materia creada exitosamente";
        } catch (Exception e) {
            return "redirect:/admin/materias-profesor?error=" + e.getMessage();
        }
    }
}