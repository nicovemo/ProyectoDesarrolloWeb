package com.Plataforma.controller;

import com.Plataforma.service.*;
import com.ctp.profesores.entity.Profesor;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/profesor")
public class ProfesorController {

    private final ProfesorService profesorService;
    private final UsuarioService usuarioService;
    private final MateriaService materiaService;
    private final ComunicadoService comunicadoService;
    private final EventoCalendarioService calendarioService;
    private final BibliotecaService bibliotecaService;

    public ProfesorController(
            ProfesorService profesorService,
            UsuarioService usuarioService,
            MateriaService materiaService,
            ComunicadoService comunicadoService,
            EventoCalendarioService calendarioService,
            BibliotecaService bibliotecaService) {
        this.profesorService = profesorService;
        this.usuarioService = usuarioService;
        this.materiaService = materiaService;
        this.comunicadoService = comunicadoService;
        this.calendarioService = calendarioService;
        this.bibliotecaService = bibliotecaService;
    }

    @GetMapping("/dashboard")
    public String dashboard(Authentication auth, Model model) {
        if (auth != null && auth.isAuthenticated()) {
            // Cargar datos del profesor
            var usuario = usuarioService.buscarPorEmail(auth.getName());
            if (usuario != null) {
                model.addAttribute("usuario", usuario);
                
                // Obtener profesor por usuario
                var profesor = profesorService.findByCorreo(usuario.getEmail());
                if (profesor.isPresent()) {
                    model.addAttribute("profesor", profesor.get());
                    
                    // Estadísticas del profesor
                    try {
                        var materias = materiaService.listar(profesor.get().getId());
                        model.addAttribute("totalMaterias", materias.size());
                        
                        var comunicados = comunicadoService.listarTodos();
                        model.addAttribute("totalComunicados", comunicados.size());
                        
                        var eventos = calendarioService.listarTodos();
                        model.addAttribute("eventosProximos", eventos.size());
                        
                    } catch (Exception e) {
                        // En caso de error, usar valores por defecto
                        model.addAttribute("totalMaterias", 0);
                        model.addAttribute("totalComunicados", 0);
                        model.addAttribute("eventosProximos", 0);
                    }
                }
            }
        }
        return "profesor/dashboard";
    }

    @GetMapping("/materias")
    public String materias(Authentication auth, Model model) {
        if (auth != null && auth.isAuthenticated()) {
            var usuario = usuarioService.buscarPorEmail(auth.getName());
            if (usuario != null) {
                var profesor = profesorService.findByCorreo(usuario.getEmail());
                if (profesor.isPresent()) {
                    model.addAttribute("profesor", profesor.get());
                    model.addAttribute("materias", materiaService.listar(profesor.get().getId()));
                }
            }
        }
        return "profesor/materias";
    }

    @GetMapping("/comunicados")
    public String comunicados(Model model) {
        model.addAttribute("comunicados", comunicadoService.listarTodos());
        return "profesor/comunicados";
    }

    @GetMapping("/calendario")
    public String calendario(Model model) {
        model.addAttribute("eventos", calendarioService.listarTodos());
        return "profesor/calendario";
    }

    @GetMapping("/biblioteca")
    public String biblioteca(Model model) {
        model.addAttribute("recursos", bibliotecaService.listar());
        return "profesor/biblioteca";
    }

    @GetMapping("/perfil")
    public String perfil(Authentication auth, Model model) {
        if (auth != null && auth.isAuthenticated()) {
            var usuario = usuarioService.buscarPorEmail(auth.getName());
            if (usuario != null) {
                var profesor = profesorService.findByCorreo(usuario.getEmail());
                if (profesor.isPresent()) {
                    model.addAttribute("profesor", profesor.get());
                }
                model.addAttribute("usuario", usuario);
            }
        }
        return "profesor/perfil";
    }
}