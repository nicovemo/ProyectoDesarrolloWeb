package com.Plataforma.controller;

import com.dev1.app.model.Usuario.Usuario;
import com.dev1.app.model.Estudiante.Estudiante;
import com.Plataforma.service.UsuarioService;
import com.Plataforma.service.EstudianteService;
import com.Plataforma.service.EventoCalendarioService;
import com.Plataforma.service.ComunicadoService;
import com.Plataforma.domain.EventoCalendario;
import com.Plataforma.domain.Comunicado;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Controller
public class AuthController {

    @Autowired
    private UsuarioService usuarioService;
    
    @Autowired
    private EstudianteService estudianteService;
    
    @Autowired
    private EventoCalendarioService eventoCalendarioService;
    
    @Autowired
    private ComunicadoService comunicadoService;

    @GetMapping("/login")
    public String login(@RequestParam(value = "error", required = false) String error, Model model) {
        if (error != null) {
            model.addAttribute("error", "Credenciales incorrectas");
        }
        return "login";
    }

    @GetMapping("/dashboard")
    public String dashboard(Model model) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        String email = auth.getName();
        
        Usuario usuario = usuarioService.buscarPorEmail(email);
        model.addAttribute("usuario", usuario);

        // Redirigir según el rol del usuario
        switch (usuario.getRol()) {
            case ADMINISTRATIVO:
                return "admin/dashboard";
            case PROFESOR:
                return "profesor/dashboard";
            case ESTUDIANTE:
                // Para estudiantes, obtener datos específicos del estudiante
                Estudiante estudiante = estudianteService.getById(usuario.getId());
                if (estudiante != null) {
                    model.addAttribute("estudiante", estudiante);
                } else {
                    System.out.println("No se encontró estudiante para usuario ID: " + usuario.getId());
                }
                
                // Obtener eventos próximos reales del calendario
                List<EventoCalendario> proximosEventos = eventoCalendarioService.obtenerProximosEventos();
                model.addAttribute("proximos", proximosEventos);
                
                // Obtener comunicados importantes para estudiantes
                List<Comunicado> comunicadosImportantes = comunicadoService.listarImportantes();
                model.addAttribute("comunicados", comunicadosImportantes);
                
                return "dashboard";
            default:
                return "dashboard";
        }
    }

    @GetMapping("/")
    public String home(Authentication authentication) {
        if (authentication != null && authentication.isAuthenticated() && 
            !authentication.getName().equals("anonymousUser")) {
            // Si está autenticado, redirigir al dashboard
            return "redirect:/dashboard";
        } else {
            // Si no está autenticado, redirigir al login
            return "redirect:/login";
        }
    }
    
    @GetMapping("/home")
    public String homePage() {
        return "index";
    }
}


