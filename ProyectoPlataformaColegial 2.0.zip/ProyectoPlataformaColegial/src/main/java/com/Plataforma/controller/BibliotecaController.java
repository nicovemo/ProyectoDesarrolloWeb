/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.Plataforma.controller;
import com.Plataforma.service.BibliotecaService;
import com.dev1.app.model.Biblioteca.BibliotecaRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;


@Controller
@RequestMapping("/biblioteca")
public class BibliotecaController {

    private final BibliotecaService service;
    private final BibliotecaRepository bibliotecaRepository;

    public BibliotecaController(BibliotecaService service, BibliotecaRepository bibliotecaRepository) {
        this.service = service;
        this.bibliotecaRepository = bibliotecaRepository;
    }

    @GetMapping
    public String biblioteca(@RequestParam(required = false) String query, Model model) {
        model.addAttribute("recursos", service.buscar(query));
        model.addAttribute("query", query);
        return "recursos/lista";
    }
    
    // === Eliminar recurso de biblioteca ===
    @PostMapping("/{id}/eliminar")
    public String eliminar(@PathVariable Long id) {
        try {
            bibliotecaRepository.deleteById(id);
            return "redirect:/biblioteca?mensaje=Recurso eliminado exitosamente";
        } catch (Exception e) {
            return "redirect:/biblioteca?error=Error al eliminar recurso: " + e.getMessage();
        }
    }
}