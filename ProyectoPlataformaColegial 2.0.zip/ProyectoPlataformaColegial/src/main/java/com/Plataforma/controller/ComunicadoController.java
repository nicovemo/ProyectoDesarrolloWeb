package com.Plataforma.controller;

import com.Plataforma.service.ComunicadoService;
import com.Plataforma.service.MateriaService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.security.core.Authentication;

@Controller
@RequestMapping("/comunicados")
public class ComunicadoController {

    private final ComunicadoService comunicadoService;
    private final MateriaService materiaService;
    
    public ComunicadoController(ComunicadoService comunicadoService, MateriaService materiaService) {
        this.comunicadoService = comunicadoService;
        this.materiaService = materiaService;
    }

    // === Listar comunicados ===
    @GetMapping
    public String listar(Model model) {
        model.addAttribute("comunicados", comunicadoService.listarTodos());
        return "comunicados/lista";
    }

    // === Ver comunicado individual ===
    @GetMapping("/{id}")
    public String ver(@PathVariable Long id, Model model) {
        try {
            model.addAttribute("comunicado", comunicadoService.buscarPorId(id));
            return "comunicados/detalle";
        } catch (Exception e) {
            return "redirect:/comunicados?error=Comunicado no encontrado";
        }
    }

    // === Formulario crear comunicado ===
    @GetMapping("/crear")
    public String formCrear(Model model) {
        return "comunicados/crear";
    }

    // === Crear comunicado ===
    @PostMapping("/crear")
    public String crear(
            @RequestParam String titulo,
            @RequestParam String cuerpo,
            Authentication authentication
    ) {
        try {
            com.Plataforma.domain.Comunicado comunicado = new com.Plataforma.domain.Comunicado();
            comunicado.setTitulo(titulo);
            comunicado.setContenido(cuerpo);
            comunicado.setEstado(com.Plataforma.domain.Comunicado.Estado.BORRADOR);
            comunicado.setPrioridad(com.Plataforma.domain.Comunicado.Prioridad.MEDIA);
            comunicado.setDirigidoA("TODOS");
            comunicadoService.crear(comunicado, authentication.getName());
            return "redirect:/comunicados";
        } catch (Exception e) {
            return "redirect:/comunicados?error=" + e.getMessage();
        }
    }

    // === Formulario editar comunicado ===
    @GetMapping("/{id}/editar")
    public String formEditar(@PathVariable Long id, Model model) {
        try {
            model.addAttribute("comunicado", comunicadoService.buscarPorId(id));
            return "comunicados/editar";
        } catch (Exception e) {
            return "redirect:/comunicados?error=Comunicado no encontrado";
        }
    }

    // === Actualizar comunicado ===
    @PostMapping("/{id}/editar")
    public String editar(
            @PathVariable Long id,
            @RequestParam String titulo,
            @RequestParam String cuerpo
    ) {
        try {
            com.Plataforma.domain.Comunicado comunicado = new com.Plataforma.domain.Comunicado();
            comunicado.setTitulo(titulo);
            comunicado.setContenido(cuerpo);
            comunicadoService.actualizar(id, comunicado);
            return "redirect:/comunicados/" + id;
        } catch (Exception e) {
            return "redirect:/comunicados?error=" + e.getMessage();
        }
    }

    // === Cambiar visibilidad ===
    @PostMapping("/{id}/visibilidad")
    public String cambiarVisibilidad(
            @PathVariable Long id,
            @RequestParam boolean visible
    ) {
        try {
            if (visible) {
                comunicadoService.publicar(id);
            } else {
                comunicadoService.archivar(id);
            }
            return "redirect:/comunicados";
        } catch (Exception e) {
            return "redirect:/comunicados?error=" + e.getMessage();
        }
    }

    // === Eliminar comunicado ===
    @PostMapping("/{id}/eliminar")
    public String eliminar(@PathVariable Long id) {
        comunicadoService.eliminar(id);
        return "redirect:/comunicados";
    }
}