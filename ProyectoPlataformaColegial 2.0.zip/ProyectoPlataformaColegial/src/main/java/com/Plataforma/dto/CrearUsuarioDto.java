package com.Plataforma.dto;

public class CrearUsuarioDto {
    private String tipoUsuario;
    private String nombre;
    private String apellido;
    private String email;
    private String cedula;
    private String telefono;
    private String password;
    
    // Campos específicos para estudiante
    private String matricula;
    private String carrera;
    private Integer nivel;
    private boolean transporteBeca;
    private boolean comedorBeca;
    
    // Campos específicos para profesor
    private String especialidad;
    
    // Campos específicos para administrativo
    private String puesto;
    private String departamento;

    // Constructores
    public CrearUsuarioDto() {}

    // Getters y Setters
    public String getTipoUsuario() { return tipoUsuario; }
    public void setTipoUsuario(String tipoUsuario) { this.tipoUsuario = tipoUsuario; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getApellido() { return apellido; }
    public void setApellido(String apellido) { this.apellido = apellido; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getCedula() { return cedula; }
    public void setCedula(String cedula) { this.cedula = cedula; }

    public String getTelefono() { return telefono; }
    public void setTelefono(String telefono) { this.telefono = telefono; }

    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }

    public String getMatricula() { return matricula; }
    public void setMatricula(String matricula) { this.matricula = matricula; }

    public String getCarrera() { return carrera; }
    public void setCarrera(String carrera) { this.carrera = carrera; }

    public Integer getNivel() { return nivel; }
    public void setNivel(Integer nivel) { this.nivel = nivel; }

    public boolean isTransporteBeca() { return transporteBeca; }
    public void setTransporteBeca(boolean transporteBeca) { this.transporteBeca = transporteBeca; }

    public boolean isComedorBeca() { return comedorBeca; }
    public void setComedorBeca(boolean comedorBeca) { this.comedorBeca = comedorBeca; }

    public String getEspecialidad() { return especialidad; }
    public void setEspecialidad(String especialidad) { this.especialidad = especialidad; }

    public String getPuesto() { return puesto; }
    public void setPuesto(String puesto) { this.puesto = puesto; }

    public String getDepartamento() { return departamento; }
    public void setDepartamento(String departamento) { this.departamento = departamento; }
}