package com.Plataforma.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.ctp.profesores.entity.Recordatorio;

public interface RecordatorioRepository extends JpaRepository<Recordatorio, Long> {
    // JpaRepository ya proporciona el método save(), no necesitamos redefinirlo
}