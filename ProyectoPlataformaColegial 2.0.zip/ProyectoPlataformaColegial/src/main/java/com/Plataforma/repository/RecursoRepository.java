package com.Plataforma.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.ctp.profesores.entity.Recurso;
import java.util.List;

public interface RecursoRepository extends JpaRepository<Recurso, Long> {
    List<Recurso> findByMateriaId(Long materiaId);
    List<Recurso> findByTituloContainingIgnoreCase(String titulo);
}