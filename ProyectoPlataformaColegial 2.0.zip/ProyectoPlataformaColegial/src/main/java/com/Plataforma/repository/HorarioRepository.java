package com.Plataforma.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.ctp.profesores.entity.Horario;
import java.util.List;

public interface HorarioRepository extends JpaRepository<Horario, Long> {
    List<Horario> findByMateriaId(Long materiaId);
}