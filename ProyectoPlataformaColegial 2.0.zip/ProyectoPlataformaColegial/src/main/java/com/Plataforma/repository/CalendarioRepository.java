/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.Plataforma.repository;

import com.ctp.profesores.entity.Evento;
import com.Plataforma.Calendario;
import java.time.LocalDateTime;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 *
 * @author Nicole Venegas
 */
public class CalendarioRepository {

    public List<Calendario> findTop3ByFechaInicioAfterOrderByFechaInicioAsc(LocalDateTime now) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public List<Calendario> findTop5ByFechaInicioAfterOrderByFechaInicioAsc(LocalDateTime now) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
  
}

/**
 *
 * @author PC-JPS01
 */
