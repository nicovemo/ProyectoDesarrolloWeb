/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.Plataforma.repository;

import com.dev1.app.model.Estudiante.Estudiante;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 *
 * @author Nicole Venegas
 */
public interface EstudianteRepository extends JpaRepository<Estudiante,Long> {
  Optional<Estudiante> findByUsuario_Id(Long id);
}

