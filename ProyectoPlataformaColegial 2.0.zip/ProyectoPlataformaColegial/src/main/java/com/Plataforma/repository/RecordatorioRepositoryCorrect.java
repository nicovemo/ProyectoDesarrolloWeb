package com.Plataforma.repository;

import com.ctp.profesores.entity.Recordatorio;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface RecordatorioRepositoryCorrect extends JpaRepository<Recordatorio, Long> {
}