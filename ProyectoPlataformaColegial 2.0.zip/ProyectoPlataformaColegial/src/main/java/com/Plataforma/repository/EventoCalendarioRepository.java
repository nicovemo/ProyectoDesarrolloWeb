package com.Plataforma.repository;

import com.Plataforma.domain.EventoCalendario;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface EventoCalendarioRepository extends JpaRepository<EventoCalendario, Long> {
    
    List<EventoCalendario> findByFechaInicioBetweenOrderByFechaInicio(LocalDateTime inicio, LocalDateTime fin);
    
    List<EventoCalendario> findByTipoOrderByFechaInicio(EventoCalendario.TipoEvento tipo);
    
    List<EventoCalendario> findByEstadoOrderByFechaInicio(EventoCalendario.EstadoEvento estado);
    
    @Query("SELECT e FROM EventoCalendario e WHERE e.participantesObjetivo IN ('TODOS', :tipoUsuario) AND e.esPublico = true ORDER BY e.fechaInicio")
    List<EventoCalendario> findEventosParaUsuario(@Param("tipoUsuario") String tipoUsuario);
    
    @Query("SELECT e FROM EventoCalendario e WHERE e.fechaInicio >= :ahora AND e.estado = 'PROGRAMADO' ORDER BY e.fechaInicio LIMIT 5")
    List<EventoCalendario> findProximosEventos(@Param("ahora") LocalDateTime ahora);
    
    List<EventoCalendario> findByTituloContainingIgnoreCaseOrderByFechaInicio(String titulo);
    
    @Query("SELECT COUNT(e) FROM EventoCalendario e WHERE e.estado = :estado")
    long countByEstado(@Param("estado") EventoCalendario.EstadoEvento estado);
    
    @Query("SELECT COUNT(e) FROM EventoCalendario e WHERE e.tipo = :tipo")
    long countByTipo(@Param("tipo") EventoCalendario.TipoEvento tipo);
    
    @Query("SELECT e FROM EventoCalendario e WHERE DATE(e.fechaInicio) = DATE(:fecha) ORDER BY e.fechaInicio")
    List<EventoCalendario> findEventosDelDia(@Param("fecha") LocalDateTime fecha);
    
    @Query("SELECT e FROM EventoCalendario e WHERE MONTH(e.fechaInicio) = MONTH(:fecha) AND YEAR(e.fechaInicio) = YEAR(:fecha) ORDER BY e.fechaInicio")
    List<EventoCalendario> findEventosDelMes(@Param("fecha") LocalDateTime fecha);
}