/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.Plataforma.repository;

import com.dev1.app.model.Biblioteca.Biblioteca;
import java.util.List;

/**
 *
 * @author Nicole Venegas
 */
public class BibliotecaRepository {

    public List<Biblioteca> findAll() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
