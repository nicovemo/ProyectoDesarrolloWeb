package com.Plataforma.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.ctp.profesores.entity.Materia;
import java.util.Optional;
import java.util.List;

public interface MateriaRepository extends JpaRepository<Materia, Long> {
    Optional<Materia> findByCodigo(String codigo);
    boolean existsByCodigo(String codigo);
    List<Materia> findByProfesorId(Long profesorId);
}