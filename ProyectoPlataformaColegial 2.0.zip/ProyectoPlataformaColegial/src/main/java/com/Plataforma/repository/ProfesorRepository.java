package com.Plataforma.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.ctp.profesores.entity.Profesor;
import com.dev1.app.model.Usuario.Usuario;
import java.util.Optional;

public interface ProfesorRepository extends JpaRepository<Profesor, Long> {
    Optional<Profesor> findByCorreo(String correo);
    Optional<Profesor> findByUsuario(Usuario usuario);
    Optional<Profesor> findByUsuarioId(Long usuarioId);
}