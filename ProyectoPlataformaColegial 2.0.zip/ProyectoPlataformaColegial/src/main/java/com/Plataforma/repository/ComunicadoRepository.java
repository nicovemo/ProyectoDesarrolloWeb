package com.Plataforma.repository;

import com.Plataforma.domain.Comunicado;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface ComunicadoRepository extends JpaRepository<Comunicado, Long> {
    
    List<Comunicado> findByEstadoOrderByFechaPublicacionDesc(Comunicado.Estado estado);
    
    List<Comunicado> findByPrioridadOrderByFechaPublicacionDesc(Comunicado.Prioridad prioridad);
    
    @Query("SELECT c FROM Comunicado c WHERE c.estado = 'PUBLICADO' AND c.dirigidoA IN ('TODOS', :tipoUsuario) ORDER BY c.fechaPublicacion DESC")
    List<Comunicado> findComunicadosParaUsuario(@Param("tipoUsuario") String tipoUsuario);
    
    @Query("SELECT c FROM Comunicado c WHERE c.fechaPublicacion BETWEEN :inicio AND :fin ORDER BY c.fechaPublicacion DESC")
    List<Comunicado> findByFechaPublicacionBetween(@Param("inicio") LocalDateTime inicio, @Param("fin") LocalDateTime fin);
    
    List<Comunicado> findByTituloContainingIgnoreCaseOrderByFechaPublicacionDesc(String titulo);
    
    @Query("SELECT COUNT(c) FROM Comunicado c WHERE c.estado = :estado")
    long countByEstado(@Param("estado") Comunicado.Estado estado);
    
    @Query("SELECT c FROM Comunicado c WHERE c.esImportante = true AND c.estado = 'PUBLICADO' ORDER BY c.fechaPublicacion DESC")
    List<Comunicado> findImportantesPublicados();
}