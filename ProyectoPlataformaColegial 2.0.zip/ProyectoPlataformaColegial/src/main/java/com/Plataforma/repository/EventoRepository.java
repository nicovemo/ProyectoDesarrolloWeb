package com.Plataforma.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.ctp.profesores.entity.Evento;
import java.util.List;

public interface EventoRepository extends JpaRepository<Evento, Long> {
    List<Evento> findByProfesorIdOrProfesorIsNullOrderByFechaInicioAsc(Long profesorId);
}