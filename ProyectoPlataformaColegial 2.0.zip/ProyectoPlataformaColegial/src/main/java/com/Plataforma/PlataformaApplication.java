/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.Plataforma;

import com.Plataforma.service.UsuarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication
@EntityScan(basePackages = {
    "com.Plataforma",
    "com.dev1.app.model",
    "com.ctp.profesores.entity"
})
@EnableJpaRepositories(basePackages = {
    "com.Plataforma.repository",
    "com.dev1.app.model"
})
public class PlataformaApplication implements CommandLineRunner {

    @Autowired
    private UsuarioService usuarioService;

    public static void main(String[] args) {
        SpringApplication.run(PlataformaApplication.class, args);
    }

    @Override
    public void run(String... args) throws Exception {
        // Comentamos temporalmente la creación de usuarios para que inicie la app
        // usuarioService.crearUsuariosDePrueba();
        System.out.println("Aplicación iniciada en puerto 8082");
        System.out.println("Acceda a http://localhost:8082 para probar la plataforma");
        System.out.println("Para crear usuarios de prueba, use los endpoints de administración");
    }
}
