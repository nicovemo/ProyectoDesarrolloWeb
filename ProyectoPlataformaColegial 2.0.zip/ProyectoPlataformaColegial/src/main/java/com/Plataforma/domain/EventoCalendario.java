package com.Plataforma.domain;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "eventos_calendario")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @ToString
public class EventoCalendario {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "El título es obligatorio")
    @Size(max = 200, message = "El título no puede exceder 200 caracteres")
    @Column(nullable = false, length = 200)
    private String titulo;

    @Lob
    @Column(columnDefinition = "TEXT")
    private String descripcion;

    @NotNull(message = "La fecha de inicio es obligatoria")
    @Column(name = "fecha_inicio", nullable = false)
    private LocalDateTime fechaInicio;

    @Column(name = "fecha_fin")
    private LocalDateTime fechaFin;

    @NotNull(message = "El tipo de evento es obligatorio")
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private TipoEvento tipo = TipoEvento.ACADEMICO;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private EstadoEvento estado = EstadoEvento.PROGRAMADO;

    @Column(name = "es_todo_el_dia")
    private Boolean esTodoElDia = false;

    @Column(name = "es_recurrente")
    private Boolean esRecurrente = false;

    @Column(name = "patron_recurrencia", length = 50)
    private String patronRecurrencia; // DIARIO, SEMANAL, MENSUAL, ANUAL

    @Column(name = "ubicacion", length = 200)
    private String ubicacion;

    @Column(name = "organizador", length = 100)
    private String organizador;

    @Column(name = "participantes_objetivo", length = 100)
    private String participantesObjetivo; // TODOS, ESTUDIANTES, PROFESORES, ADMINISTRATIVOS

    @Column(name = "color", length = 7)
    private String color = "#007bff"; // Color por defecto azul

    @Column(name = "es_publico")
    private Boolean esPublico = true;

    @Column(name = "requiere_confirmacion")
    private Boolean requiereConfirmacion = false;

    @Column(name = "limite_participantes")
    private Integer limiteParticipantes;

    @Column(name = "enlace_externo", length = 500)
    private String enlaceExterno; // Para reuniones virtuales

    @Column(name = "recordatorios", length = 100)
    private String recordatorios; // Minutos antes del evento, separados por comas

    @Column(name = "creado_por", length = 100)
    private String creadoPor;

    @Column(name = "creado_en", nullable = false)
    private LocalDateTime creadoEn = LocalDateTime.now();

    @Column(name = "actualizado_en")
    private LocalDateTime actualizadoEn;

    public enum TipoEvento {
        ACADEMICO("Académico", "#28a745"),
        ADMINISTRATIVO("Administrativo", "#6c757d"),
        SOCIAL("Social", "#fd7e14"),
        DEPORTIVO("Deportivo", "#20c997"),
        CULTURAL("Cultural", "#e83e8c"),
        EXAMENES("Exámenes", "#dc3545"),
        VACACIONES("Vacaciones", "#6f42c1"),
        REUNION("Reunión", "#17a2b8"),
        CONFERENCIA("Conferencia", "#ffc107"),
        OTRO("Otro", "#343a40");

        private final String nombre;
        private final String colorPorDefecto;

        TipoEvento(String nombre, String colorPorDefecto) {
            this.nombre = nombre;
            this.colorPorDefecto = colorPorDefecto;
        }

        public String getNombre() { return nombre; }
        public String getColorPorDefecto() { return colorPorDefecto; }
    }

    public enum EstadoEvento {
        PROGRAMADO("Programado", "primary"),
        EN_CURSO("En Curso", "warning"),
        COMPLETADO("Completado", "success"),
        CANCELADO("Cancelado", "danger"),
        POSPUESTO("Pospuesto", "secondary");

        private final String nombre;
        private final String cssClass;

        EstadoEvento(String nombre, String cssClass) {
            this.nombre = nombre;
            this.cssClass = cssClass;
        }

        public String getNombre() { return nombre; }
        public String getCssClass() { return cssClass; }
    }

    @PrePersist
    protected void onCreate() {
        creadoEn = LocalDateTime.now();
        if (color == null || color.isEmpty()) {
            color = tipo.getColorPorDefecto();
        }
    }

    @PreUpdate
    protected void onUpdate() {
        actualizadoEn = LocalDateTime.now();
    }

    // Métodos de utilidad
    public boolean isEnCurso() {
        LocalDateTime ahora = LocalDateTime.now();
        return fechaInicio.isBefore(ahora) && 
               (fechaFin == null || fechaFin.isAfter(ahora));
    }

    public boolean isCompletado() {
        return estado == EstadoEvento.COMPLETADO || 
               (fechaFin != null && LocalDateTime.now().isAfter(fechaFin));
    }

    public boolean isCancelado() {
        return estado == EstadoEvento.CANCELADO;
    }

    public long getDuracionEnMinutos() {
        if (fechaFin == null) return 60; // 1 hora por defecto
        return java.time.Duration.between(fechaInicio, fechaFin).toMinutes();
    }

    // Getters manuales para compatibilidad
    public Long getId() { return id; }
    public String getTitulo() { return titulo; }
    public String getDescripcion() { return descripcion; }
    public LocalDateTime getFechaInicio() { return fechaInicio; }
    public LocalDateTime getFechaFin() { return fechaFin; }
    public TipoEvento getTipo() { return tipo; }
    public EstadoEvento getEstado() { return estado; }
    public Boolean getEsTodoElDia() { return esTodoElDia; }
    public Boolean getEsRecurrente() { return esRecurrente; }
    public String getPatronRecurrencia() { return patronRecurrencia; }
    public String getUbicacion() { return ubicacion; }
    public String getOrganizador() { return organizador; }
    public String getParticipantesObjetivo() { return participantesObjetivo; }
    public String getColor() { return color; }
    public Boolean getEsPublico() { return esPublico; }
    public Boolean getRequiereConfirmacion() { return requiereConfirmacion; }
    public Integer getLimiteParticipantes() { return limiteParticipantes; }
    public String getEnlaceExterno() { return enlaceExterno; }
    public String getRecordatorios() { return recordatorios; }
    public String getCreadoPor() { return creadoPor; }
    public LocalDateTime getCreadoEn() { return creadoEn; }
    public LocalDateTime getActualizadoEn() { return actualizadoEn; }
    
    // Setters manuales para compatibilidad
    public void setTitulo(String titulo) { this.titulo = titulo; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }
    public void setFechaInicio(LocalDateTime fechaInicio) { this.fechaInicio = fechaInicio; }
    public void setFechaFin(LocalDateTime fechaFin) { this.fechaFin = fechaFin; }
    public void setTipo(TipoEvento tipo) { this.tipo = tipo; }
    public void setEstado(EstadoEvento estado) { this.estado = estado; }
    public void setEsTodoElDia(Boolean esTodoElDia) { this.esTodoElDia = esTodoElDia; }
    public void setEsRecurrente(Boolean esRecurrente) { this.esRecurrente = esRecurrente; }
    public void setPatronRecurrencia(String patronRecurrencia) { this.patronRecurrencia = patronRecurrencia; }
    public void setUbicacion(String ubicacion) { this.ubicacion = ubicacion; }
    public void setOrganizador(String organizador) { this.organizador = organizador; }
    public void setParticipantesObjetivo(String participantesObjetivo) { this.participantesObjetivo = participantesObjetivo; }
    public void setColor(String color) { this.color = color; }
    public void setEsPublico(Boolean esPublico) { this.esPublico = esPublico; }
    public void setRequiereConfirmacion(Boolean requiereConfirmacion) { this.requiereConfirmacion = requiereConfirmacion; }
    public void setLimiteParticipantes(Integer limiteParticipantes) { this.limiteParticipantes = limiteParticipantes; }
    public void setEnlaceExterno(String enlaceExterno) { this.enlaceExterno = enlaceExterno; }
    public void setRecordatorios(String recordatorios) { this.recordatorios = recordatorios; }
    public void setCreadoPor(String creadoPor) { this.creadoPor = creadoPor; }
    public void setCreadoEn(LocalDateTime creadoEn) { this.creadoEn = creadoEn; }
    public void setActualizadoEn(LocalDateTime actualizadoEn) { this.actualizadoEn = actualizadoEn; }
}