package com.Plataforma.domain;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "comunicados")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @ToString
public class Comunicado {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "El título es obligatorio")
    @Size(max = 200, message = "El título no puede exceder 200 caracteres")
    @Column(nullable = false, length = 200)
    private String titulo;

    @NotBlank(message = "El contenido es obligatorio")
    @Lob
    @Column(nullable = false, columnDefinition = "TEXT")
    private String contenido;

    @NotNull(message = "La prioridad es obligatoria")
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private Prioridad prioridad = Prioridad.MEDIA;

    @NotNull(message = "El estado es obligatorio")
    @Enumerated(EnumType.STRING) 
    @Column(nullable = false)
    private Estado estado = Estado.BORRADOR;

    @Column(name = "dirigido_a", length = 50)
    private String dirigidoA; // TODOS, ESTUDIANTES, PROFESORES, ADMINISTRATIVOS

    @Column(name = "fecha_publicacion")
    private LocalDateTime fechaPublicacion;

    @Column(name = "fecha_vencimiento")
    private LocalDateTime fechaVencimiento;

    @Column(name = "creado_por", length = 100)
    private String creadoPor;

    @Column(name = "creado_en", nullable = false)
    private LocalDateTime creadoEn = LocalDateTime.now();

    @Column(name = "actualizado_en")
    private LocalDateTime actualizadoEn;

    @Column(name = "es_importante")
    private Boolean esImportante = false;

    @Column(name = "permitir_comentarios")
    private Boolean permitirComentarios = true;

    @Column(name = "adjuntos")
    private String adjuntos; // URLs separadas por comas

    public enum Prioridad {
        ALTA("Alta", "danger"),
        MEDIA("Media", "warning"),
        BAJA("Baja", "info");

        private final String nombre;
        private final String cssClass;

        Prioridad(String nombre, String cssClass) {
            this.nombre = nombre;
            this.cssClass = cssClass;
        }

        public String getNombre() { return nombre; }
        public String getCssClass() { return cssClass; }
    }

    public enum Estado {
        BORRADOR("Borrador", "secondary"),
        PUBLICADO("Publicado", "success"),
        PROGRAMADO("Programado", "primary"),
        ARCHIVADO("Archivado", "dark");

        private final String nombre;
        private final String cssClass;

        Estado(String nombre, String cssClass) {
            this.nombre = nombre;
            this.cssClass = cssClass;
        }

        public String getNombre() { return nombre; }
        public String getCssClass() { return cssClass; }
    }

    @PrePersist
    protected void onCreate() {
        creadoEn = LocalDateTime.now();
    }

    @PreUpdate 
    protected void onUpdate() {
        actualizadoEn = LocalDateTime.now();
    }

    // Métodos de utilidad
    public boolean isPublicado() {
        return estado == Estado.PUBLICADO;
    }

    public boolean isVencido() {
        return fechaVencimiento != null && LocalDateTime.now().isAfter(fechaVencimiento);
    }

    public boolean isProgramado() {
        return estado == Estado.PROGRAMADO && fechaPublicacion != null && LocalDateTime.now().isBefore(fechaPublicacion);
    }

    // Getters manuales para compatibilidad
    public Long getId() { return id; }
    public String getTitulo() { return titulo; }
    public String getContenido() { return contenido; }
    public Prioridad getPrioridad() { return prioridad; }
    public Estado getEstado() { return estado; }
    public String getDirigidoA() { return dirigidoA; }
    public LocalDateTime getFechaPublicacion() { return fechaPublicacion; }
    public LocalDateTime getFechaVencimiento() { return fechaVencimiento; }
    public String getCreadoPor() { return creadoPor; }
    public LocalDateTime getCreadoEn() { return creadoEn; }
    public LocalDateTime getActualizadoEn() { return actualizadoEn; }
    public Boolean getEsImportante() { return esImportante; }
    public Boolean getPermitirComentarios() { return permitirComentarios; }
    public String getAdjuntos() { return adjuntos; }
    
    // Setters manuales para compatibilidad
    public void setTitulo(String titulo) { this.titulo = titulo; }
    public void setContenido(String contenido) { this.contenido = contenido; }
    public void setPrioridad(Prioridad prioridad) { this.prioridad = prioridad; }
    public void setEstado(Estado estado) { this.estado = estado; }
    public void setDirigidoA(String dirigidoA) { this.dirigidoA = dirigidoA; }
    public void setFechaPublicacion(LocalDateTime fechaPublicacion) { this.fechaPublicacion = fechaPublicacion; }
    public void setFechaVencimiento(LocalDateTime fechaVencimiento) { this.fechaVencimiento = fechaVencimiento; }
    public void setCreadoPor(String creadoPor) { this.creadoPor = creadoPor; }
    public void setEsImportante(Boolean esImportante) { this.esImportante = esImportante; }
    public void setPermitirComentarios(Boolean permitirComentarios) { this.permitirComentarios = permitirComentarios; }
    public void setAdjuntos(String adjuntos) { this.adjuntos = adjuntos; }
    public void setCreadoEn(LocalDateTime creadoEn) { this.creadoEn = creadoEn; }
    public void setActualizadoEn(LocalDateTime actualizadoEn) { this.actualizadoEn = actualizadoEn; }
}