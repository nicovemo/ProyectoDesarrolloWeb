package com.Plataforma.service;

import com.Plataforma.domain.EventoCalendario;
import com.Plataforma.repository.EventoCalendarioRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.time.YearMonth;
import java.util.List;

@Service
public class EventoCalendarioService {

    private final EventoCalendarioRepository eventoRepository;
    
    public EventoCalendarioService(EventoCalendarioRepository eventoRepository) {
        this.eventoRepository = eventoRepository;
    }

    @Transactional(readOnly = true)
    public List<EventoCalendario> listarTodos() {
        return eventoRepository.findAll();
    }

    @Transactional(readOnly = true)
    public List<EventoCalendario> listarPorRangoFechas(LocalDateTime inicio, LocalDateTime fin) {
        return eventoRepository.findByFechaInicioBetweenOrderByFechaInicio(inicio, fin);
    }

    @Transactional(readOnly = true)
    public List<EventoCalendario> listarPorTipo(EventoCalendario.TipoEvento tipo) {
        return eventoRepository.findByTipoOrderByFechaInicio(tipo);
    }

    @Transactional(readOnly = true)
    public List<EventoCalendario> listarPorEstado(EventoCalendario.EstadoEvento estado) {
        return eventoRepository.findByEstadoOrderByFechaInicio(estado);
    }

    @Transactional(readOnly = true)
    public List<EventoCalendario> listarParaUsuario(String tipoUsuario) {
        return eventoRepository.findEventosParaUsuario(tipoUsuario);
    }

    @Transactional(readOnly = true)
    public List<EventoCalendario> obtenerProximosEventos() {
        return eventoRepository.findProximosEventos(LocalDateTime.now());
    }

    @Transactional(readOnly = true)
    public List<EventoCalendario> buscarPorTitulo(String titulo) {
        return eventoRepository.findByTituloContainingIgnoreCaseOrderByFechaInicio(titulo);
    }

    @Transactional(readOnly = true)
    public EventoCalendario buscarPorId(Long id) {
        return eventoRepository.findById(id).orElse(null);
    }

    @Transactional(readOnly = true)
    public List<EventoCalendario> obtenerEventosDelDia(LocalDateTime fecha) {
        return eventoRepository.findEventosDelDia(fecha);
    }

    @Transactional(readOnly = true)
    public List<EventoCalendario> obtenerEventosDelMes(int año, int mes) {
        YearMonth yearMonth = YearMonth.of(año, mes);
        LocalDateTime fecha = yearMonth.atDay(1).atStartOfDay();
        return eventoRepository.findEventosDelMes(fecha);
    }

    @Transactional(readOnly = true)
    public long contarPorEstado(EventoCalendario.EstadoEvento estado) {
        return eventoRepository.countByEstado(estado);
    }

    @Transactional(readOnly = true)
    public long contarPorTipo(EventoCalendario.TipoEvento tipo) {
        return eventoRepository.countByTipo(tipo);
    }

    @Transactional
    public EventoCalendario crear(EventoCalendario evento, String creadoPor) {
        evento.setCreadoPor(creadoPor);
        evento.setCreadoEn(LocalDateTime.now());
        
        // Asignar color por defecto si no se especifica
        if (evento.getColor() == null || evento.getColor().isEmpty()) {
            evento.setColor(evento.getTipo().getColorPorDefecto());
        }
        
        // Si no se especifica fecha fin y no es todo el día, asignar 1 hora
        if (evento.getFechaFin() == null && !evento.getEsTodoElDia()) {
            evento.setFechaFin(evento.getFechaInicio().plusHours(1));
        }
        
        return eventoRepository.save(evento);
    }

    @Transactional
    public EventoCalendario actualizar(Long id, EventoCalendario eventoActualizado) {
        EventoCalendario evento = eventoRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Evento no encontrado: " + id));

        evento.setTitulo(eventoActualizado.getTitulo());
        evento.setDescripcion(eventoActualizado.getDescripcion());
        evento.setFechaInicio(eventoActualizado.getFechaInicio());
        evento.setFechaFin(eventoActualizado.getFechaFin());
        evento.setTipo(eventoActualizado.getTipo());
        evento.setEstado(eventoActualizado.getEstado());
        evento.setEsTodoElDia(eventoActualizado.getEsTodoElDia());
        evento.setUbicacion(eventoActualizado.getUbicacion());
        evento.setOrganizador(eventoActualizado.getOrganizador());
        evento.setParticipantesObjetivo(eventoActualizado.getParticipantesObjetivo());
        evento.setColor(eventoActualizado.getColor());
        evento.setEsPublico(eventoActualizado.getEsPublico());
        evento.setRequiereConfirmacion(eventoActualizado.getRequiereConfirmacion());
        evento.setLimiteParticipantes(eventoActualizado.getLimiteParticipantes());
        evento.setEnlaceExterno(eventoActualizado.getEnlaceExterno());
        evento.setActualizadoEn(LocalDateTime.now());

        return eventoRepository.save(evento);
    }

    @Transactional
    public void eliminar(Long id) {
        eventoRepository.deleteById(id);
    }

    @Transactional
    public EventoCalendario cambiarEstado(Long id, EventoCalendario.EstadoEvento nuevoEstado) {
        EventoCalendario evento = eventoRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Evento no encontrado: " + id));

        evento.setEstado(nuevoEstado);
        evento.setActualizadoEn(LocalDateTime.now());
        
        return eventoRepository.save(evento);
    }

    @Transactional
    public EventoCalendario cancelar(Long id) {
        return cambiarEstado(id, EventoCalendario.EstadoEvento.CANCELADO);
    }

    @Transactional
    public EventoCalendario completar(Long id) {
        return cambiarEstado(id, EventoCalendario.EstadoEvento.COMPLETADO);
    }

    @Transactional
    public EventoCalendario posponer(Long id) {
        return cambiarEstado(id, EventoCalendario.EstadoEvento.POSPUESTO);
    }
}