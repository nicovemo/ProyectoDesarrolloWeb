package com.Plataforma.service;

import com.Plataforma.repository.RecursoRepository;
import com.Plataforma.repository.MateriaRepository;
import com.Plataforma.repository.ProfesorRepository;
import com.ctp.profesores.entity.*;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import java.nio.file.*;
import java.io.IOException;
import java.util.UUID;
import java.util.List;

@Service
public class RecursoService {

    private final RecursoRepository recursoRepo;
    private final MateriaRepository materiaRepo;
    private final ProfesorRepository profesorRepo;

    public RecursoService(RecursoRepository r, MateriaRepository m, ProfesorRepository p) {
        this.recursoRepo = r;
        this.materiaRepo = m;
        this.profesorRepo = p;
    }

    public Recurso guardar(Long materiaId, Long profesorId, MultipartFile file, String titulo, String descripcion) throws IOException {
        // Validar que existe el profesor
        Profesor p = profesorRepo.findById(profesorId)
                .orElseThrow(() -> new RuntimeException("Profesor no encontrado con ID: " + profesorId));
        
        // Validar que existe la materia
        Materia m = materiaRepo.findById(materiaId)
                .orElseThrow(() -> new RuntimeException("Materia no encontrada con ID: " + materiaId));
        
        // Validar archivo
        if (file.isEmpty()) {
            throw new RuntimeException("El archivo está vacío");
        }
        
        if (file.getOriginalFilename() == null || file.getOriginalFilename().trim().isEmpty()) {
            throw new RuntimeException("Nombre de archivo inválido");
        }
        
        // Generar nombre de archivo seguro
        String originalName = file.getOriginalFilename();
        String extension = "";
        int lastDot = originalName.lastIndexOf('.');
        if (lastDot > 0) {
            extension = originalName.substring(lastDot);
        }
        String stored = UUID.randomUUID().toString() + extension;
        
        // Crear directorio si no existe
        Path uploadsDir = Path.of("uploads");
        if (!Files.exists(uploadsDir)) {
            Files.createDirectories(uploadsDir);
        }
        
        Path target = uploadsDir.resolve(stored);
        
        try {
            // Copiar archivo
            Files.copy(file.getInputStream(), target, StandardCopyOption.REPLACE_EXISTING);
            
            // Crear entidad
            Recurso r = new Recurso();
            r.setProfesor(p);
            r.setMateria(m);
            r.setTitulo(titulo != null ? titulo.trim() : "Sin título");
            r.setDescripcion(descripcion != null ? descripcion.trim() : "");
            r.setFilename(stored);
            r.setOriginalName(originalName);
            r.setContentType(file.getContentType());
            r.setSize(file.getSize());
            
            return recursoRepo.save(r);
            
        } catch (IOException e) {
            // Limpiar archivo si falló la base de datos
            try {
                Files.deleteIfExists(target);
            } catch (IOException cleanupException) {
                // Log del error de limpieza
            }
            throw new IOException("Error al guardar archivo: " + e.getMessage(), e);
        }
    }
    
    public List<Recurso> buscar(String query) {
        if (query == null || query.trim().isEmpty()) {
            return recursoRepo.findAll();
        }
        // Si hay query, buscar por título que contenga el texto
        return recursoRepo.findByTituloContainingIgnoreCase(query.trim());
    }
    
    public List<Recurso> listarTodos() {
        return recursoRepo.findAll();
    }
    
    public void eliminar(Long id) throws IOException {
        Recurso recurso = recursoRepo.findById(id)
            .orElseThrow(() -> new RuntimeException("Recurso no encontrado con ID: " + id));
        
        // Eliminar archivo físico
        Path filePath = Path.of("uploads", recurso.getFilename());
        try {
            Files.deleteIfExists(filePath);
        } catch (IOException e) {
            System.err.println("Error al eliminar archivo físico: " + e.getMessage());
            // Continuar con la eliminación de BD aunque falle el archivo
        }
        
        // Eliminar de base de datos
        recursoRepo.deleteById(id);
    }
}
