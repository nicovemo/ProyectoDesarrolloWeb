// ARCHIVO MOVIDO A REPOSITORY PACKAGE
// Este archivo debería estar en com.Plataforma.repository como EventoRepository
// y extender JpaRepository correctamente.
// Ver EventoRepository.java en el package repository
