package com.Plataforma.service;

import com.Plataforma.repository.RecordatorioRepository;
import com.Plataforma.repository.ProfesorRepository;
import com.Plataforma.repository.EventoRepository;
import com.ctp.profesores.entity.Recordatorio;
import com.ctp.profesores.entity.Evento;
import com.ctp.profesores.entity.Profesor;
import com.dev1.app.model.Usuario.Usuario;
import com.dev1.app.model.Usuario.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class RecordatorioService {

    @Autowired
    private RecordatorioRepository repo;
    
    @Autowired
    private ProfesorRepository profesorRepo;
    
    @Autowired
    private EventoRepository eventoRepo;
    
    @Autowired
    private UsuarioRepository usuarioRepo;

    public void enviar(Long profesorId, String asunto, String cuerpo, java.util.List<String> correos) {
        SimpleMailMessage msg = new SimpleMailMessage();
        msg.setSubject(asunto);
        msg.setText(cuerpo);
        msg.setTo(correos.toArray(String[]::new));
        Profesor prof = profesorRepo.findById(profesorId).orElseThrow();
        Recordatorio rec = new Recordatorio();
        rec.setProfesor(prof);
        rec.setAsunto(asunto);
        rec.setCuerpo(cuerpo);
        rec.setDestino(String.join(",", correos));
        repo.save(rec);
    }
    
    @Transactional
    public Recordatorio crear(Long eventoId, Long usuarioId, Integer anticipacionMinutos, String medio) {

        Evento evento = eventoRepo.findById(eventoId)
                .orElseThrow(() -> new IllegalArgumentException("Evento no encontrado: " + eventoId));

        Usuario usuario = usuarioRepo.findById(usuarioId)
                .orElseThrow(() -> new IllegalArgumentException("Usuario no encontrado: " + usuarioId));

        Recordatorio r = new Recordatorio();
        r.setEvento(evento);
        r.setUsuario(usuario);

        if (anticipacionMinutos != null && anticipacionMinutos > 0)
            r.setAnticipacionMinutos(anticipacionMinutos);

        if (medio != null && !medio.isBlank())
            r.setMedio(medio);

        return repo.save(r);
    }
}

