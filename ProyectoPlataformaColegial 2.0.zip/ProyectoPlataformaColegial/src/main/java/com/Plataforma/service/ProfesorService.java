package com.Plataforma.service;

import com.ctp.profesores.entity.Profesor;
import com.Plataforma.repository.ProfesorRepository;
import org.springframework.stereotype.Service;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import java.util.Optional;

@Service
public class ProfesorService {

    private final ProfesorRepository repo;
    private final BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();

    public ProfesorService(ProfesorRepository repo) {
        this.repo = repo;
    }

    public Profesor registrar(String nombre, String correo, String password) {
        Profesor p = new Profesor();
        p.setNombre(nombre);
        p.setCorreo(correo);
        p.setPasswordHash(encoder.encode(password));
        p.setActivo(true);
        return repo.save(p);
    }

    public Optional<Profesor> findByCorreo(String correo) {
        return repo.findByCorreo(correo);
    }
}
