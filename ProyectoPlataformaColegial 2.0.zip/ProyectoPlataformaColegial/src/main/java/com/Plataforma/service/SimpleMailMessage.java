// ARCHIVO ELIMINADO - Se usa org.springframework.mail.SimpleMailMessage directamente
// Las implementaciones personalizadas de clases Spring Boot no son necesarias
// y pueden causar conflictos de nombres de clases.
