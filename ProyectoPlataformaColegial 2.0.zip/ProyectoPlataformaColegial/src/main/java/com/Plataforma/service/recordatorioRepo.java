// ARCHIVO MOVIDO A REPOSITORY PACKAGE
// Este archivo debería estar en com.Plataforma.repository como RecordatorioRepository
// y extender JpaRepository correctamente.
// Ver RecordatorioRepository.java en el package repository
