package com.Plataforma.service;

import com.Plataforma.domain.Comunicado;
import com.Plataforma.repository.ComunicadoRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class ComunicadoService {

    private final ComunicadoRepository comunicadoRepository;
    
    public ComunicadoService(ComunicadoRepository comunicadoRepository) {
        this.comunicadoRepository = comunicadoRepository;
    }

    @Transactional(readOnly = true)
    public List<Comunicado> listarTodos() {
        return comunicadoRepository.findAll();
    }

    @Transactional(readOnly = true)
    public List<Comunicado> listarPublicados() {
        return comunicadoRepository.findByEstadoOrderByFechaPublicacionDesc(Comunicado.Estado.PUBLICADO);
    }

    @Transactional(readOnly = true)
    public List<Comunicado> listarPorPrioridad(Comunicado.Prioridad prioridad) {
        return comunicadoRepository.findByPrioridadOrderByFechaPublicacionDesc(prioridad);
    }

    @Transactional(readOnly = true)
    public List<Comunicado> listarParaUsuario(String tipoUsuario) {
        return comunicadoRepository.findComunicadosParaUsuario(tipoUsuario);
    }

    @Transactional(readOnly = true)
    public List<Comunicado> buscarPorTitulo(String titulo) {
        return comunicadoRepository.findByTituloContainingIgnoreCaseOrderByFechaPublicacionDesc(titulo);
    }

    @Transactional(readOnly = true)
    public Comunicado buscarPorId(Long id) {
        return comunicadoRepository.findById(id).orElse(null);
    }

    @Transactional(readOnly = true)
    public long contarPorEstado(Comunicado.Estado estado) {
        return comunicadoRepository.countByEstado(estado);
    }

    @Transactional(readOnly = true)
    public List<Comunicado> listarImportantes() {
        return comunicadoRepository.findImportantesPublicados();
    }

    @Transactional
    public Comunicado crear(Comunicado comunicado, String creadoPor) {
        comunicado.setCreadoPor(creadoPor);
        comunicado.setCreadoEn(LocalDateTime.now());
        
        // Si el estado es PUBLICADO y no tiene fecha de publicación, asignar ahora
        if (comunicado.getEstado() == Comunicado.Estado.PUBLICADO && comunicado.getFechaPublicacion() == null) {
            comunicado.setFechaPublicacion(LocalDateTime.now());
        }
        
        return comunicadoRepository.save(comunicado);
    }

    @Transactional
    public Comunicado actualizar(Long id, Comunicado comunicadoActualizado) {
        Comunicado comunicado = comunicadoRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Comunicado no encontrado: " + id));

        comunicado.setTitulo(comunicadoActualizado.getTitulo());
        comunicado.setContenido(comunicadoActualizado.getContenido());
        comunicado.setPrioridad(comunicadoActualizado.getPrioridad());
        comunicado.setEstado(comunicadoActualizado.getEstado());
        comunicado.setDirigidoA(comunicadoActualizado.getDirigidoA());
        comunicado.setFechaPublicacion(comunicadoActualizado.getFechaPublicacion());
        comunicado.setFechaVencimiento(comunicadoActualizado.getFechaVencimiento());
        comunicado.setEsImportante(comunicadoActualizado.getEsImportante());
        comunicado.setPermitirComentarios(comunicadoActualizado.getPermitirComentarios());
        comunicado.setActualizadoEn(LocalDateTime.now());

        return comunicadoRepository.save(comunicado);
    }

    @Transactional
    public void eliminar(Long id) {
        comunicadoRepository.deleteById(id);
    }

    @Transactional
    public Comunicado publicar(Long id) {
        Comunicado comunicado = comunicadoRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Comunicado no encontrado: " + id));

        comunicado.setEstado(Comunicado.Estado.PUBLICADO);
        comunicado.setFechaPublicacion(LocalDateTime.now());
        
        return comunicadoRepository.save(comunicado);
    }

    @Transactional
    public Comunicado archivar(Long id) {
        Comunicado comunicado = comunicadoRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Comunicado no encontrado: " + id));

        comunicado.setEstado(Comunicado.Estado.ARCHIVADO);
        
        return comunicadoRepository.save(comunicado);
    }
}