/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.Plataforma.service;

import com.Plataforma.repository.EstudianteRepository;
import com.dev1.app.model.Estudiante.Estudiante;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author Nicole Venegas
 */
@Service
public class EstudianteService {
    @Autowired 
    EstudianteRepository estudianteRepo;
    
    public Estudiante getById(Long id){
        return estudianteRepo.findByUsuario_Id(id).orElse(null);
    }
    
    /**
     * Obtiene estadísticas académicas del estudiante
     */
    public Map<String, Object> obtenerEstadisticasAcademicas(Long estudianteId) {
        Map<String, Object> estadisticas = new HashMap<>();
        
        Estudiante estudiante = getById(estudianteId);
        if (estudiante != null) {
            // Estadísticas básicas
            estadisticas.put("nivel", estudiante.getNivel() != null ? estudiante.getNivel() : 1);
            estadisticas.put("carrera", estudiante.getCarrera() != null ? estudiante.getCarrera() : "Sin carrera asignada");
            estadisticas.put("matricula", estudiante.getMatricula() != null ? estudiante.getMatricula() : "Sin matrícula");
            
            // Estado de becas
            estadisticas.put("becasActivas", 
                (estudiante.getTransporteBeca() != null && estudiante.getTransporteBeca() ? 1 : 0) +
                (estudiante.getComedorBeca() != null && estudiante.getComedorBeca() ? 1 : 0)
            );
            
            // Simulación de datos académicos (pueden ser reemplazados por datos reales)
            estadisticas.put("materiasInscritas", 6); // Dato simulado
            estadisticas.put("promedioGeneral", 85.5); // Dato simulado
            estadisticas.put("creditosObtenidos", estudiante.getNivel() != null ? estudiante.getNivel() * 30 : 30);
            estadisticas.put("asistenciaPromedio", 92.0); // Dato simulado
        }
        
        return estadisticas;
    }
}

