/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package com.Plataforma.service;

import com.Plataforma.repository.AdministrativoRepository;
import com.dev1.app.model.Administrativo.Administrativo;
import com.dev1.app.model.Usuario.Rol;
import com.dev1.app.model.Usuario.Usuario;
import com.dev1.app.model.Usuario.UsuarioRepository;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class AdministrativoService {

    private final AdministrativoRepository administrativoRepository;
    private final UsuarioRepository usuarioRepository;
    
    public AdministrativoService(AdministrativoRepository administrativoRepository, UsuarioRepository usuarioRepository) {
        this.administrativoRepository = administrativoRepository;
        this.usuarioRepository = usuarioRepository;
    }


    // === LISTAR TODOS ===
    @Transactional(readOnly = true)
    public List<Administrativo> listar() {
        return administrativoRepository.findAll();
    }

    // === BUSCAR POR ID ===
    @Transactional(readOnly = true)
    public Administrativo buscarPorId(Long id) {
        return administrativoRepository.findById(id).orElse(null);
    }

    // === BUSCAR POR USUARIO ID ===
    @Transactional(readOnly = true)
    public java.util.Optional<Administrativo> buscarPorUsuarioId(Long usuarioId) {
        return administrativoRepository.findAll().stream()
            .filter(admin -> admin.getUsuario() != null && admin.getUsuario().getId().equals(usuarioId))
            .findFirst();
    }

    // === CREAR ADMINISTRATIVO A PARTIR DE UN USUARIO ===
    @Transactional
    public Administrativo crearDesdeUsuario(Long usuarioId, String puesto, String departamento) {

        Usuario u = usuarioRepository.findById(usuarioId)
            .orElseThrow(() ->
                    new IllegalArgumentException("Usuario no encontrado: " + usuarioId));

        // Cambiar el rol del usuario
        u.setRol(Rol.ADMINISTRATIVO);

        // Crear Administrativo
        Administrativo a = new Administrativo();
        a.setUsuario(u);
        a.setPuesto(puesto);
        a.setDepartamento(departamento);
        a.setActivo(true);

        return administrativoRepository.save(a);
    }

    // === GUARDAR O ACTUALIZAR UN ADMINISTRATIVO ===
    @Transactional
    public Administrativo guardar(Administrativo a) {
        return administrativoRepository.save(a);
    }

    // === ELIMINAR ===
    @Transactional
    public void eliminar(Long id) {
        administrativoRepository.deleteById(id);
    }
}