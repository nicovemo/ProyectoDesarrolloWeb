package com.Plataforma.service;

import com.dev1.app.model.Usuario.Rol;
import com.dev1.app.model.Usuario.Usuario;
import com.dev1.app.model.Usuario.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UsuarioService {

    @Autowired
    private UsuarioRepository usuarioRepository;
    
    @Autowired
    private PasswordEncoder passwordEncoder;

    public List<Usuario> listarTodos() {
        return usuarioRepository.findAll();
    }

    public Usuario buscarPorId(Long id) {
        return usuarioRepository.findById(id).orElse(null);
    }

    public Usuario buscarPorEmail(String email) {
        return usuarioRepository.findByEmail(email).orElse(null);
    }

    public Usuario guardar(Usuario usuario) {
        // Encriptar la contraseña antes de guardar
        if (usuario.getPassword() != null && !usuario.getPassword().isEmpty()) {
            usuario.setPassword(passwordEncoder.encode(usuario.getPassword()));
        }
        return usuarioRepository.save(usuario);
    }

    public void eliminar(Long id) {
        usuarioRepository.deleteById(id);
    }

    public Optional<Usuario> findByEmail(String email) {
        return usuarioRepository.findByEmail(email);
    }

    public List<Usuario> buscarPorRol(Rol rol) {
        return usuarioRepository.findByRol(rol);
    }

    public boolean existeEmail(String email) {
        return usuarioRepository.findByEmail(email).isPresent();
    }

    // Método para crear usuarios de prueba (solo para desarrollo)
    public void crearUsuariosDePrueba() {
        if (!existeEmail("admin@plataforma.edu")) {
            Usuario admin = new Usuario();
            admin.setUsername("admin");
            admin.setEmail("admin@plataforma.edu");
            admin.setPassword("admin123");
            admin.setNombre("Administrador");
            admin.setApellido("Sistema");
            admin.setRol(Rol.ADMINISTRATIVO);
            guardar(admin);
        }

        if (!existeEmail("profesor@plataforma.edu")) {
            Usuario profesor = new Usuario();
            profesor.setUsername("profesor");
            profesor.setEmail("profesor@plataforma.edu");
            profesor.setPassword("profesor123");
            profesor.setNombre("Juan Carlos");
            profesor.setApellido("Pérez Rodríguez");
            profesor.setRol(Rol.PROFESOR);
            guardar(profesor);
        }

        if (!existeEmail("estudiante@plataforma.edu")) {
            Usuario estudiante = new Usuario();
            estudiante.setUsername("estudiante");
            estudiante.setEmail("estudiante@plataforma.edu");
            estudiante.setPassword("estudiante123");
            estudiante.setNombre("María José");
            estudiante.setApellido("González López");
            estudiante.setRol(Rol.ESTUDIANTE);
            guardar(estudiante);
        }
    }
}