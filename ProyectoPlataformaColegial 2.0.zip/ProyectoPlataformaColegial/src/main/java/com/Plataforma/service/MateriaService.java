package com.Plataforma.service;

import com.Plataforma.repository.MateriaRepository;
import com.Plataforma.repository.ProfesorRepository;
import com.ctp.profesores.entity.*;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class MateriaService {

    private final MateriaRepository materiaRepo;
    private final ProfesorRepository profesorRepo;
    
    public MateriaService(MateriaRepository m, ProfesorRepository p) {
        this.materiaRepo = m;
        this.profesorRepo = p;
    }

    public java.util.List<Materia> listar(Long profesorId) {
        return materiaRepo.findByProfesorId(profesorId);
    }

    public Materia crear(String nombre, String codigo, Long profesorId, String especialidad, String descripcion) {
        Profesor prof = profesorRepo.findById(profesorId).orElseThrow(() -> 
            new RuntimeException("Profesor no encontrado con ID: " + profesorId));
        
        // Verificar que el código no exista
        if (materiaRepo.existsByCodigo(codigo)) {
            throw new RuntimeException("Ya existe una materia con el código: " + codigo);
        }
        
        Materia m = new Materia();
        m.setNombre(nombre);
        m.setCodigo(codigo);
        m.setProfesor(prof);
        m.setEspecialidad(especialidad);
        m.setDescripcion(descripcion);
        return materiaRepo.save(m);
    }

    public List<Materia> listar() {
        return materiaRepo.findAll();
    }

    public void eliminar(Long id) {
        if (!materiaRepo.existsById(id)) {
            throw new RuntimeException("Materia no encontrada con ID: " + id);
        }
        materiaRepo.deleteById(id);
    }
    
    public Materia buscarPorId(Long id) {
        return materiaRepo.findById(id).orElseThrow(() -> 
            new RuntimeException("Materia no encontrada con ID: " + id));
    }
    
    public Materia actualizar(Long id, String nombre, String codigo, Long profesorId, String especialidad, String descripcion) {
        Materia materia = buscarPorId(id);
        Profesor profesor = profesorRepo.findById(profesorId).orElseThrow(() -> 
            new RuntimeException("Profesor no encontrado con ID: " + profesorId));
        
        // Verificar que el código no exista en otra materia
        if (!materia.getCodigo().equals(codigo) && materiaRepo.existsByCodigo(codigo)) {
            throw new RuntimeException("Ya existe una materia con el código: " + codigo);
        }
        
        materia.setNombre(nombre);
        materia.setCodigo(codigo);
        materia.setProfesor(profesor);
        materia.setEspecialidad(especialidad);
        materia.setDescripcion(descripcion);
        
        return materiaRepo.save(materia);
    }
}
