/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.dev1.app.model.Administrativo;

import com.dev1.app.model.Usuario.Usuario;
import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "administrativos")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @ToString
public class Administrativo {

    @Id
    private Long id; // mismo id que Usuario

    @Column(nullable = false, length = 100)
    private String puesto;

    @Column(nullable = false, length = 100)
    private String departamento;

    @Column(nullable = false)
    private Boolean activo = true;

    @OneToOne
    @MapsId
    @JoinColumn(name = "id")
    private Usuario usuario;
    
    // Getters manuales para compatibilidad
    public Long getId() { return id; }
    public String getPuesto() { return puesto; }
    public String getDepartamento() { return departamento; }
    public Boolean getActivo() { return activo; }
    public Usuario getUsuario() { return usuario; }
    
    // Setters manuales para compatibilidad
    public void setId(Long id) { this.id = id; }
    public void setPuesto(String puesto) { this.puesto = puesto; }
    public void setDepartamento(String departamento) { this.departamento = departamento; }
    public void setActivo(Boolean activo) { this.activo = activo; }
    public void setUsuario(Usuario usuario) { this.usuario = usuario; }
}

    

