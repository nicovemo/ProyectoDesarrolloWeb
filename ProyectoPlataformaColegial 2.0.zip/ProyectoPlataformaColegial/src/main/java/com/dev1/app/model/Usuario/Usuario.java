package com.dev1.app.model.Usuario;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import java.time.LocalDateTime;

/**
 * Entidad Usuario para el sistema de plataforma colegial
 */
@Entity
@Table(name = "usuarios")
public class Usuario {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(unique = true, nullable = false, length = 50)
    private String username;
    
    @Column(unique = true, nullable = false, length = 100)
    private String email;
    
    @Column(name = "password", nullable = false)
    private String password;
    
    @Column(name = "password_hash", nullable = false)
    private String passwordHash;
    
    @Column(length = 50)
    private String nombre;
    
    @Column(length = 50) 
    private String apellido;
    
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private Rol rol = Rol.ESTUDIANTE;
    
    @Column(nullable = false)
    private Boolean activo = true;
    
    @Column(nullable = false)
    private LocalDateTime fechaCreacion = LocalDateTime.now();
    
    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
        this.passwordHash = password; // Mantener ambos campos sincronizados
    }

    public String getPasswordHash() {
        return passwordHash;
    }

    public void setPasswordHash(String passwordHash) {
        this.passwordHash = passwordHash;
        this.password = passwordHash; // Mantener ambos campos sincronizados
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public Rol getRol() {
        return rol;
    }

    public void setRol(Rol rol) {
        this.rol = rol;
    }

    // Método de compatibilidad para AdminController
    public void setTipoUsuario(String tipoUsuario) {
        if (tipoUsuario != null) {
            switch (tipoUsuario.toUpperCase()) {
                case "ESTUDIANTE":
                    this.rol = Rol.ESTUDIANTE;
                    break;
                case "PROFESOR":
                    this.rol = Rol.PROFESOR;
                    break;
                case "ADMINISTRATIVO":
                    this.rol = Rol.ADMINISTRATIVO;
                    break;
                default:
                    this.rol = Rol.ESTUDIANTE;
            }
        }
    }

    public Boolean getActivo() {
        return activo;
    }

    public void setActivo(Boolean activo) {
        this.activo = activo;
    }

    public LocalDateTime getFechaCreacion() {
        return fechaCreacion;
    }

    public void setFechaCreacion(LocalDateTime fechaCreacion) {
        this.fechaCreacion = fechaCreacion;
    }
    
    // Métodos adicionales para compatibilidad con controladores
    public String getTelefono() {
        // Como Usuario no tiene teléfono directamente, devuelve null
        // Los controladores deberían obtener el teléfono de Estudiante/Profesor
        return null;
    }
    
    public void setTelefono(String telefono) {
        // Método vacío para compatibilidad - el teléfono se guarda en las entidades específicas
    }
    
    public String getCorreo() {
        return this.email; // Alias para compatibilidad
    }
    
    public void setCorreo(String correo) {
        this.email = correo; // Alias para compatibilidad
    }
}