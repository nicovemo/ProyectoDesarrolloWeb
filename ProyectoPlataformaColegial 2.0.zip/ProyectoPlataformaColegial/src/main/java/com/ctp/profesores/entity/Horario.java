package com.ctp.profesores.entity;
import jakarta.persistence.*; import jakarta.validation.constraints.*;
@Entity public class Horario{
  @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
  @ManyToOne(optional=false) private Materia materia;
  @Min(1) @Max(7) private int diaSemana;
  @NotNull private java.time.LocalTime horaInicio;
  @NotNull private java.time.LocalTime horaFin;
  @Column(length=40) private String aula;
  public Long getId(){return id;} public void setId(Long id){this.id=id;}
  public Materia getMateria(){return materia;} public void setMateria(Materia m){this.materia=m;}
  public int getDiaSemana(){return diaSemana;} public void setDiaSemana(int d){this.diaSemana=d;}
  public java.time.LocalTime getHoraInicio(){return horaInicio;} public void setHoraInicio(java.time.LocalTime t){this.horaInicio=t;}
  public java.time.LocalTime getHoraFin(){return horaFin;} public void setHoraFin(java.time.LocalTime t){this.horaFin=t;}
  public String getAula(){return aula;} public void setAula(String a){this.aula=a;}
}