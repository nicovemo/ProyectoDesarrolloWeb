package com.ctp.profesores.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import java.time.LocalDateTime;

@Entity(name = "ComunicadoProfesores")
@Table(name = "comunicados_profesores")
public class Comunicado {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @ManyToOne(optional = false)
    private Materia materia;
    @NotBlank
    @Column(length = 150)
    private String titulo;
    @NotBlank
    @Lob
    private String cuerpo;
    private LocalDateTime fechaPublicacion = LocalDateTime.now();
    private boolean visible = true;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Materia getMateria() {
        return materia;
    }

    public void setMateria(Materia m) {
        this.materia = m;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String t) {
        this.titulo = t;
    }

    public String getCuerpo() {
        return cuerpo;
    }

    public void setCuerpo(String c) {
        this.cuerpo = c;
    }

    public LocalDateTime getFechaPublicacion() {
        return fechaPublicacion;
    }

    public void setFechaPublicacion(LocalDateTime f) {
        this.fechaPublicacion = f;
    }

    public boolean isVisible() {
        return visible;
    }

    public void setVisible(boolean v) {
        this.visible = v;
    }
}
