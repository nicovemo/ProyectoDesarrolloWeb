package com.ctp.profesores.entity;

import com.dev1.app.model.Usuario.Usuario;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import java.time.LocalDateTime;

@Entity
public class Recordatorio {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @ManyToOne(optional = true)
    private Profesor profesor;
    
    @ManyToOne(optional = true)
    private Evento evento;
    
    @ManyToOne(optional = true)
    private Usuario usuario;
    
    @Column(nullable = false)
    private Integer anticipacionMinutos = 60; // 1 hora por defecto

    @Column(nullable = false, length = 20)
    private String medio = "INAPP"; // luego puedes añadir EMAIL/SMS
    
    @Column(length = 150)
    private String asunto;
    
    @Lob
    private String cuerpo;
    
    @Lob
    private String destino;
    
    @Column(nullable = false)
    private LocalDateTime creadoEn = LocalDateTime.now();
    
    private LocalDateTime fechaEnvio;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Profesor getProfesor() {
        return profesor;
    }

    public void setProfesor(Profesor p) {
        this.profesor = p;
    }

    public String getAsunto() {
        return asunto;
    }

    public void setAsunto(String a) {
        this.asunto = a;
    }

    public String getCuerpo() {
        return cuerpo;
    }

    public void setCuerpo(String c) {
        this.cuerpo = c;
    }

    public String getDestino() {
        return destino;
    }

    public void setDestino(String d) {
        this.destino = d;
    }

    public LocalDateTime getFechaEnvio() {
        return fechaEnvio;
    }

    public void setFechaEnvio(LocalDateTime f) {
        this.fechaEnvio = f;
    }

    public Evento getEvento() {
        return evento;
    }

    public void setEvento(Evento evento) {
        this.evento = evento;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public Integer getAnticipacionMinutos() {
        return anticipacionMinutos;
    }

    public void setAnticipacionMinutos(Integer anticipacionMinutos) {
        this.anticipacionMinutos = anticipacionMinutos;
    }

    public String getMedio() {
        return medio;
    }

    public void setMedio(String medio) {
        this.medio = medio;
    }

    public LocalDateTime getCreadoEn() {
        return creadoEn;
    }

    public void setCreadoEn(LocalDateTime creadoEn) {
        this.creadoEn = creadoEn;
    }
}
