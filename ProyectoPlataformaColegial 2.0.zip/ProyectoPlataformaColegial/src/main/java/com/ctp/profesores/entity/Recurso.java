package com.ctp.profesores.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import java.time.LocalDateTime;

@Entity
public class Recurso {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @ManyToOne(optional = false)
    private Materia materia;
    @ManyToOne(optional = false)
    private Profesor profesor;
    @NotBlank
    @Column(length = 150)
    private String titulo;
    @Lob
    private String descripcion;
    @NotBlank
    private String filename;
    @NotBlank
    private String originalName;
    private String contentType;
    private Long size;
    private LocalDateTime fechaSubida = LocalDateTime.now();

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Materia getMateria() {
        return materia;
    }

    public void setMateria(Materia m) {
        this.materia = m;
    }

    public Profesor getProfesor() {
        return profesor;
    }

    public void setProfesor(Profesor p) {
        this.profesor = p;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String t) {
        this.titulo = t;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String d) {
        this.descripcion = d;
    }

    public String getFilename() {
        return filename;
    }

    public void setFilename(String f) {
        this.filename = f;
    }

    public String getOriginalName() {
        return originalName;
    }

    public void setOriginalName(String o) {
        this.originalName = o;
    }

    public String getContentType() {
        return contentType;
    }

    public void setContentType(String c) {
        this.contentType = c;
    }

    public Long getSize() {
        return size;
    }

    public void setSize(Long s) {
        this.size = s;
    }

    public LocalDateTime getFechaSubida() {
        return fechaSubida;
    }

    public void setFechaSubida(LocalDateTime f) {
        this.fechaSubida = f;
    }
}
