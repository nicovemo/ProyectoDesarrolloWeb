package com.ctp.profesores.entity;
import jakarta.persistence.*; import jakarta.validation.constraints.*;

@Entity public class Materia{
  @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
  @NotBlank @Column(length=120) private String nombre;
  @NotBlank @Column(length=30,unique=true) private String codigo;
  @ManyToOne(optional=false) private Profesor profesor;
  @Column(length=100) private String especialidad;
  @Column(length=500) private String descripcion;
  
  public Long getId(){return id;} public void setId(Long id){this.id=id;}
  public String getNombre(){return nombre;} public void setNombre(String n){this.nombre=n;}
  public String getCodigo(){return codigo;} public void setCodigo(String c){this.codigo=c;}
  public Profesor getProfesor(){return profesor;} public void setProfesor(Profesor p){this.profesor=p;}
  public String getEspecialidad(){return especialidad;} public void setEspecialidad(String e){this.especialidad=e;}
  public String getDescripcion(){return descripcion;} public void setDescripcion(String d){this.descripcion=d;}
}